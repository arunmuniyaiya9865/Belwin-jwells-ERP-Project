const express = require('express');
const router = express.Router();
const { getNextExpenseId, createExpense, getExpenses, getExpenseById, updateExpense, deleteExpense } = require('../controllers/expenseController');

router.get('/next-id', getNextExpenseId);
router.post('/', createExpense);
router.get('/', getExpenses);
router.get('/:expenseId', getExpenseById);
router.put('/:id', updateExpense);
router.delete('/:id', deleteExpense);

module.exports = router;
