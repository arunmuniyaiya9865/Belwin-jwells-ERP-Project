const Expense = require('../models/Expense');

// @desc    Get next Expense ID
// @route   GET /api/expenses/next-id
// @access  Public
const getNextExpenseId = async (req, res) => {
  try {
    const lastExpense = await Expense.findOne().sort({ createdAt: -1 });
    let nextId = 'EXP000001';
    
    if (lastExpense && lastExpense.expenseId && lastExpense.expenseId.startsWith('EXP')) {
      const currentNumber = parseInt(lastExpense.expenseId.replace('EXP', ''), 10);
      if (!isNaN(currentNumber)) {
        nextId = `EXP${String(currentNumber + 1).padStart(6, '0')}`;
      }
    }
    
    res.json({ nextId });
  } catch (error) {
    console.error('Error getting next expense ID:', error);
    res.status(500).json({ message: 'Server Error', error: error.message });
  }
};

// @desc    Create new expense
// @route   POST /api/expenses
// @access  Public
const createExpense = async (req, res) => {
  try {
    const {
      expenseId, expenseDate, branchName, expenseCategory, expenseSubCategory,
      expenseAmount, paymentMode, paidToVendorName, description, billInvoiceNo,
      billReceiptUpload, paymentReferenceNo, approvedBy, enteredBy, gstIncluded, taxAmount
    } = req.body;

    if (!expenseId || !expenseDate || !branchName || !expenseCategory || !expenseAmount || !paymentMode || !paidToVendorName) {
      return res.status(400).json({ message: 'Please provide all required fields' });
    }

    if (parseFloat(expenseAmount) <= 0) {
      return res.status(400).json({ message: 'Expense amount must be greater than 0' });
    }

    const expenseExists = await Expense.findOne({ expenseId });
    if (expenseExists) {
      return res.status(400).json({ message: `Expense ID ${expenseId} already exists` });
    }

    const expense = await Expense.create({
      expenseId, expenseDate, branchName, expenseCategory, expenseSubCategory,
      expenseAmount, paymentMode, paidToVendorName, description, billInvoiceNo,
      billReceiptUpload, paymentReferenceNo, approvedBy, enteredBy, gstIncluded, taxAmount,
      amount: expenseAmount
    });

    res.status(201).json(expense);
  } catch (error) {
    console.error('Error creating expense:', error);
    res.status(500).json({ message: 'Server Error', error: error.message });
  }
};

// @desc    Get all expenses
// @route   GET /api/expenses
// @access  Public
const getExpenses = async (req, res) => {
  try {
    const expenses = await Expense.find().sort({ createdAt: -1 });
    res.json(expenses);
  } catch (error) {
    console.error('Error fetching expenses:', error);
    res.status(500).json({ message: 'Server Error', error: error.message });
  }
};

// @desc    Get expense by ID
// @route   GET /api/expenses/:expenseId
// @access  Public
const getExpenseById = async (req, res) => {
  try {
    const expense = await Expense.findOne({ expenseId: req.params.expenseId });
    if (!expense) {
      return res.status(404).json({ message: 'Expense not found' });
    }
    res.json(expense);
  } catch (error) {
    console.error('Error fetching expense:', error);
    res.status(500).json({ message: 'Server Error', error: error.message });
  }
};

// @desc    Update expense
// @route   PUT /api/expenses/:id
// @access  Public
const updateExpense = async (req, res) => {
  try {
    const { id } = req.params;
    const updateData = { ...req.body };

    // Business rules: cannot edit expenseId or created date
    delete updateData.expenseId;
    delete updateData.createdAt;

    if (updateData.expenseAmount !== undefined) {
      if (parseFloat(updateData.expenseAmount) <= 0) {
        return res.status(400).json({ message: 'Expense amount must be greater than 0' });
      }
      updateData.amount = updateData.expenseAmount; // Keep 'amount' in sync
    }

    // Maintain audit trail
    updateData.updatedAt = new Date();
    // Assuming enteredBy or a separate field represents the user making the update
    if (req.body.enteredBy) {
      updateData.updatedBy = req.body.enteredBy;
    }

    const updatedExpense = await Expense.findByIdAndUpdate(id, updateData, { new: true });

    if (!updatedExpense) {
      return res.status(404).json({ message: 'Expense not found' });
    }

    res.json(updatedExpense);
  } catch (error) {
    console.error('Error updating expense:', error);
    res.status(500).json({ message: 'Server Error', error: error.message });
  }
};

// @desc    Delete expense
// @route   DELETE /api/expenses/:id
// @access  Public
const deleteExpense = async (req, res) => {
  try {
    const { id } = req.params;
    const deletedExpense = await Expense.findByIdAndDelete(id);

    if (!deletedExpense) {
      return res.status(404).json({ message: 'Expense not found' });
    }

    res.json({ message: 'Expense deleted successfully' });
  } catch (error) {
    console.error('Error deleting expense:', error);
    res.status(500).json({ message: 'Server Error', error: error.message });
  }
};

module.exports = {
  getNextExpenseId,
  createExpense,
  getExpenses,
  getExpenseById,
  updateExpense,
  deleteExpense
};
