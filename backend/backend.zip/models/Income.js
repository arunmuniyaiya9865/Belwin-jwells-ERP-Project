const mongoose = require('mongoose');

const incomeSchema = new mongoose.Schema({
  incomeId: { type: String, unique: true, index: true },
  amount: { type: Number, required: true },
  description: { type: String, required: true },
  incomeDate: { type: Date, required: true }
}, { timestamps: true });

module.exports = mongoose.model('Income', incomeSchema);
