import { useState, useEffect } from 'react';
import { Plus, Edit3, Trash2, Search, BookOpen, ArrowLeft } from 'lucide-react';
import api from '../../../services/api';
import PageHeader from '../../../components/ui/PageHeader';
import Card from '../../../components/ui/Card';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';
import Badge from '../../../components/ui/Badge';
import DataTable from '../../../components/ui/DataTable';
import ConfirmDialog from '../../../components/ui/ConfirmDialog';
import { TD, TR } from '../../../components/ui/Table';

const STORAGE_KEY = 'bellwin_ledger_master';

const LedgerMaster = () => {
  const [ledgers, setLedgers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingLedger, setEditingLedger] = useState(null);
  const [formData, setFormData] = useState({
    ledgerCode: '',
    ledgerName: '',
    accountGroup: '',
    openingBalance: '',
    balanceType: 'Debit',
    branch: '',
    description: '',
    status: 'Active'
  });

  const [deleteId, setDeleteId] = useState(null);

  const fetchLedgers = async () => {
    setLoading(true);
    try {
      const res = await api.get('/accounts/ledger');
      setLedgers(res.data.ledgers || res.data || []);
    } catch {
      const local = localStorage.getItem(STORAGE_KEY);
      setLedgers(local ? JSON.parse(local) : []);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLedgers();
  }, []);

  const handleOpenAdd = () => {
    setEditingLedger(null);
    setFormData({
      ledgerCode: `LDR-${String(ledgers.length + 1).padStart(4, '0')}`,
      ledgerName: '',
      accountGroup: '',
      openingBalance: '',
      balanceType: 'Debit',
      branch: '',
      description: '',
      status: 'Active'
    });
    setIsFormOpen(true);
  };

  const handleOpenEdit = (ledger) => {
    setEditingLedger(ledger);
    setFormData({
      ledgerCode: ledger.ledgerCode || '',
      ledgerName: ledger.ledgerName || '',
      accountGroup: ledger.accountGroup || '',
      openingBalance: ledger.openingBalance || '',
      balanceType: ledger.balanceType || 'Debit',
      branch: ledger.branch || '',
      description: ledger.description || '',
      status: ledger.status || 'Active'
    });
    setIsFormOpen(true);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    if (!formData.ledgerName || !formData.accountGroup) return alert('Name and Group are required');

    setLoading(true);
    try {
      if (editingLedger) {
        try {
          await api.put(`/accounts/ledger/${editingLedger._id}`, formData);
        } catch {
          const updated = ledgers.map(v => v._id === editingLedger._id ? { ...v, ...formData } : v);
          localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
        }
      } else {
        try {
          await api.post('/accounts/ledger', formData);
        } catch {
          const newRec = { _id: Date.now().toString(), ...formData };
          const updated = [...ledgers, newRec];
          localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
        }
      }
      setIsFormOpen(false);
      fetchLedgers();
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    setLoading(true);
    try {
      try {
        await api.delete(`/accounts/ledger/${deleteId}`);
      } catch {
        const updated = ledgers.filter(v => v._id !== deleteId);
        localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      }
      setDeleteId(null);
      fetchLedgers();
    } finally {
      setLoading(false);
    }
  };

  const filtered = ledgers.filter(v =>
    String(v.ledgerName || '').toLowerCase().includes(search.toLowerCase()) ||
    String(v.ledgerCode || '').toLowerCase().includes(search.toLowerCase()) ||
    String(v.accountGroup || '').toLowerCase().includes(search.toLowerCase())
  );

  if (isFormOpen) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-6 animate-fade-in">
        <div className="flex items-center gap-4 mb-6">
          <button 
            onClick={() => setIsFormOpen(false)}
            className="p-2 text-gray-500 hover:text-green-600 hover:bg-green-50 rounded-xl transition-colors"
          >
            <ArrowLeft size={24} />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              {editingLedger ? 'Edit Ledger Master' : 'Add New Ledger'}
            </h1>
          </div>
        </div>

        <Card className="p-8 shadow-lg border border-gray-100">
          <form onSubmit={handleSave} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                label="Ledger Code"
                required
                disabled
                value={formData.ledgerCode}
                onChange={(e) => setFormData({ ...formData, ledgerCode: e.target.value.toUpperCase() })}
              />
              <Input
                label="Ledger Name"
                required
                value={formData.ledgerName}
                onChange={(e) => setFormData({ ...formData, ledgerName: e.target.value })}
                placeholder="e.g. Salary Account"
              />
              <Select
                label="Account Group"
                required
                value={formData.accountGroup}
                onChange={(e) => setFormData({ ...formData, accountGroup: e.target.value })}
              >
                <option value="">Select Group</option>
                <option value="Indirect Expenses">Indirect Expenses</option>
                <option value="Direct Expenses">Direct Expenses</option>
                <option value="Fixed Assets">Fixed Assets</option>
                <option value="Current Assets">Current Assets</option>
                <option value="Sundry Debtors">Sundry Debtors</option>
                <option value="Sundry Creditors">Sundry Creditors</option>
              </Select>
              <Select
                label="Branch"
                value={formData.branch}
                onChange={(e) => setFormData({ ...formData, branch: e.target.value })}
              >
                <option value="">Select Branch</option>
                <option value="Head Office">Head Office</option>
                <option value="Branch A">Branch A</option>
              </Select>
              <Input
                label="Opening Balance"
                type="number"
                value={formData.openingBalance}
                onChange={(e) => setFormData({ ...formData, openingBalance: e.target.value })}
                placeholder="0.00"
              />
              <Select
                label="Balance Type"
                value={formData.balanceType}
                onChange={(e) => setFormData({ ...formData, balanceType: e.target.value })}
              >
                <option value="Debit">Debit (Dr)</option>
                <option value="Credit">Credit (Cr)</option>
              </Select>
              <Select
                label="Status"
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value })}
              >
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </Select>
            </div>
            
            <div className="mt-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full border border-gray-300 rounded-lg p-2 focus:ring-green-500 focus:border-green-500"
                rows="3"
                placeholder="Optional details..."
              />
            </div>

            <div className="flex items-center justify-end gap-4 pt-6 border-t border-gray-100 mt-6">
              <Button type="button" onClick={() => setIsFormOpen(false)} variant="secondary" className="px-6 py-2.5">
                Cancel
              </Button>
              <Button type="submit" variant="primary" loading={loading} className="px-8 py-2.5 shadow-md">
                Save Ledger
              </Button>
            </div>
          </form>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 animate-fade-in">
      <PageHeader
        title="Ledger Master"
        subtitle="Create and manage individual ledger accounts."
        icon={BookOpen}
        actions={<Button onClick={handleOpenAdd} icon={Plus} variant="primary">Add Ledger</Button>}
      />

      <Card className="p-4 mb-6 shadow-sm border border-gray-100">
        <div className="relative max-w-md">
          <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
            <Search size={16} />
          </span>
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by Code, Name or Group..."
            className="w-full pl-9 pr-4 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-1 focus:ring-green-500 bg-gray-50"
          />
        </div>
      </Card>

      <DataTable
        headers={['Code', 'Name', 'Group', 'Branch', 'Op. Balance', 'Status', 'Actions']}
        data={filtered}
        loading={loading}
        renderRow={(item) => (
          <TR key={item._id}>
            <TD className="font-bold text-gray-800">{item.ledgerCode}</TD>
            <TD className="font-semibold">{item.ledgerName}</TD>
            <TD>{item.accountGroup}</TD>
            <TD>{item.branch || 'Head Office'}</TD>
            <TD className="font-semibold text-green-700">₹{item.openingBalance || '0.00'} ({item.balanceType})</TD>
            <TD><Badge variant={item.status === 'Active' ? 'success' : 'danger'}>{item.status}</Badge></TD>
            <TD>
              <div className="flex items-center gap-2">
                <button onClick={() => handleOpenEdit(item)} className="p-1.5 text-gray-500 hover:text-green-600 hover:bg-green-50 rounded-lg"><Edit3 size={15} /></button>
                <button onClick={() => setDeleteId(item._id)} className="p-1.5 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-lg"><Trash2 size={15} /></button>
              </div>
            </TD>
          </TR>
        )}
      />

      <ConfirmDialog
        isOpen={!!deleteId}
        onClose={() => setDeleteId(null)}
        onConfirm={handleDelete}
        title="Delete Ledger"
        description="Are you sure you want to delete this ledger? This action cannot be undone."
        confirmText="Delete"
        cancelText="Cancel"
        variant="danger"
      />
    </div>
  );
};

export default LedgerMaster;
