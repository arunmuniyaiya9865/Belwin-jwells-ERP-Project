import { useState, useEffect } from 'react';
import { Settings, Save, RefreshCw } from 'lucide-react';
import api from '../../../services/api';
import PageHeader from '../../../components/ui/PageHeader';
import Card from '../../../components/ui/Card';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';
import toast from 'react-hot-toast';

const STORAGE_KEY = 'bellwin_master_config';

const MasterConfig = () => {
  const [loading, setLoading] = useState(false);
  
  const [formData, setFormData] = useState({
    companyName: '',
    companyCode: '',
    gstNumber: '',
    panNumber: '',
    address: '',
    mobileNumber: '',
    email: '',
    financialYear: '2023-2024',
    currency: 'INR',
    defaultInterestRate: '',
    defaultGoldRate: '',
    loanSettings: 'Standard',
    notificationSettings: 'Email & SMS',
    securitySettings: 'High',
    status: 'Active'
  });

  const fetchConfig = async () => {
    setLoading(true);
    try {
      const res = await api.get('/master/config');
      if (res.data) setFormData(res.data);
    } catch {
      const local = localStorage.getItem(STORAGE_KEY);
      if (local) setFormData(JSON.parse(local));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchConfig();
  }, []);

  const handleSave = async (e) => {
    e.preventDefault();
    if (!formData.companyName) return alert('Company Name is required');

    setLoading(true);
    try {
      try {
        await api.post('/master/config', formData);
      } catch {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(formData));
      }
      toast.success('Configuration Saved Successfully');
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    fetchConfig();
    toast.success('Reset to saved values');
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 animate-fade-in">
      <PageHeader 
        title="Master Configuration" 
        subtitle="Manage general ERP settings." 
        icon={Settings} 
      />

      <Card className="p-8 shadow-lg border border-gray-100">
        <form onSubmit={handleSave} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input label="Company Name" required value={formData.companyName} onChange={(e) => setFormData({ ...formData, companyName: e.target.value })} />
            <Input label="Company Code" value={formData.companyCode} onChange={(e) => setFormData({ ...formData, companyCode: e.target.value })} />
            
            <Input label="GST Number" value={formData.gstNumber} onChange={(e) => setFormData({ ...formData, gstNumber: e.target.value })} />
            <Input label="PAN Number" value={formData.panNumber} onChange={(e) => setFormData({ ...formData, panNumber: e.target.value })} />
            
            <Input label="Mobile Number" value={formData.mobileNumber} onChange={(e) => setFormData({ ...formData, mobileNumber: e.target.value })} />
            <Input label="Email" type="email" value={formData.email} onChange={(e) => setFormData({ ...formData, email: e.target.value })} />
            
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">Address</label>
              <textarea value={formData.address} onChange={(e) => setFormData({ ...formData, address: e.target.value })} className="w-full border border-gray-300 rounded-lg p-2 focus:ring-green-500" rows="3" />
            </div>

            <Select label="Financial Year" value={formData.financialYear} onChange={(e) => setFormData({ ...formData, financialYear: e.target.value })}>
              <option value="2023-2024">2023-2024</option>
              <option value="2024-2025">2024-2025</option>
            </Select>
            <Select label="Currency" value={formData.currency} onChange={(e) => setFormData({ ...formData, currency: e.target.value })}>
              <option value="INR">INR (₹)</option>
              <option value="USD">USD ($)</option>
            </Select>

            <Input label="Default Interest Rate (%)" type="number" step="0.01" value={formData.defaultInterestRate} onChange={(e) => setFormData({ ...formData, defaultInterestRate: e.target.value })} />
            <Input label="Default Gold Rate (per gram)" type="number" value={formData.defaultGoldRate} onChange={(e) => setFormData({ ...formData, defaultGoldRate: e.target.value })} />

            <Select label="Loan Settings" value={formData.loanSettings} onChange={(e) => setFormData({ ...formData, loanSettings: e.target.value })}>
              <option value="Standard">Standard</option>
              <option value="Strict">Strict</option>
            </Select>
            <Select label="Notification Settings" value={formData.notificationSettings} onChange={(e) => setFormData({ ...formData, notificationSettings: e.target.value })}>
              <option value="Email & SMS">Email & SMS</option>
              <option value="Email Only">Email Only</option>
              <option value="SMS Only">SMS Only</option>
            </Select>

            <Select label="Security Settings" value={formData.securitySettings} onChange={(e) => setFormData({ ...formData, securitySettings: e.target.value })}>
              <option value="Standard">Standard</option>
              <option value="High">High</option>
            </Select>
            <Select label="Status" value={formData.status} onChange={(e) => setFormData({ ...formData, status: e.target.value })}>
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
            </Select>

          </div>
          
          <div className="flex justify-end gap-4 pt-6 border-t mt-6">
            <Button type="button" onClick={handleReset} variant="secondary" icon={RefreshCw} className="px-6 py-2.5">Reset</Button>
            <Button type="submit" variant="primary" icon={Save} loading={loading} className="px-8 py-2.5 shadow-md">Save Settings</Button>
          </div>
        </form>
      </Card>
    </div>
  );
};
export default MasterConfig;
