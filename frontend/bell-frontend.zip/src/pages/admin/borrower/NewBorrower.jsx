import { useState, useEffect, useRef } from 'react';
import { User, Save, RefreshCw, Upload, Shield } from 'lucide-react';
import toast from 'react-hot-toast';
import api from '../../../services/api';
import PageHeader from '../../../components/ui/PageHeader';
import Card from '../../../components/ui/Card';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';

const STORAGE_KEY = 'belwin_customers';
const BRANCHES = ['Head Office', 'Branch 01', 'Branch 02'];

const NewBorrower = () => {
  const [loading, setLoading] = useState(false);
  const [borrowerId, setBorrowerId] = useState('');
  const fileInputRef = useRef(null);

  const initialForm = {
    customerName: '',
    guardian: '', // guardianName / Father name
    dob: '',
    age: '',
    gender: 'Male',
    mobileNumber: '',
    alternateNumber: '',
    aadhaarNo: '',
    panNo: '',
    doorNo: '',
    area: '',
    city: '',
    postalCode: '',
    permanentAddress: '',
    temporaryAddress: '',
    occupation: '',
    monthlyIncome: '',
    branch: 'Head Office',
    memberId: '',
    status: 'Active',
    photo: ''
  };

  const [formData, setFormData] = useState(initialForm);

  const fetchNextId = async () => {
    try {
      const res = await api.get('/customers/next-id');
      setBorrowerId(res.data.customerId || res.data);
    } catch (err) {
      console.warn('API next-id not available, generating client-side ID');
      const local = localStorage.getItem(STORAGE_KEY);
      const list = local ? JSON.parse(local) : [];
      setBorrowerId(`CUST${String(list.length + 1).padStart(6, '0')}`);
    }
  };

  useEffect(() => {
    fetchNextId();
  }, []);

  // Compute addresses
  useEffect(() => {
    const parts = [formData.doorNo, formData.area, formData.city, formData.postalCode].filter(p => p && p.trim() !== '');
    if (parts.length > 0) {
      const newAddress = parts.join(', ');
      setFormData(prev => ({
        ...prev,
        permanentAddress: newAddress,
        temporaryAddress: newAddress // Default same
      }));
    }
  }, [formData.doorNo, formData.area, formData.city, formData.postalCode]);

  // Age calculation from DOB
  useEffect(() => {
    if (formData.dob) {
      const birthDate = new Date(formData.dob);
      const difference = Date.now() - birthDate.getTime();
      const ageDate = new Date(difference);
      const computedAge = Math.abs(ageDate.getUTCFullYear() - 1970);
      setFormData(prev => ({ ...prev, age: computedAge }));
    }
  }, [formData.dob]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    // Mobile validation
    if ((name === 'mobileNumber' || name === 'alternateNumber') && value !== '' && !/^[0-9]+$/.test(value)) return;
    setFormData(prev => ({ ...prev, [name]: value.toUpperCase() }));
  };

  const handlePhotoUpload = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, photo: reader.result }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleClear = () => {
    setFormData({ ...initialForm });
    if (fileInputRef.current) fileInputRef.current.value = '';
    fetchNextId();
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.customerName || !formData.mobileNumber || !formData.doorNo) {
      toast.error('Please enter Name, Mobile and Address');
      return;
    }
    if (formData.mobileNumber.length !== 10) {
      toast.error('Mobile number must be 10 digits');
      return;
    }

    setLoading(true);
    const submissionData = {
      ...formData,
      customerId: borrowerId,
      // mapping to schema
      customerName: formData.customerName,
      guardianName: formData.guardian,
      dateOfBirth: formData.dob,
      age: parseInt(formData.age) || 18,
      gender: formData.gender,
      mobileNumber: formData.mobileNumber,
      aadhaarNumber: formData.aadhaarNo,
      panNumber: formData.panNo,
      doorStreet: formData.doorNo,
      area: formData.area,
      city: formData.city,
      postalCode: formData.postalCode,
      branchName: formData.branch,
      status: formData.status === 'Active' ? 'Approved' : 'Customer Approval Pending', // align to schema
      customerPhotoUrl: formData.photo
    };

    try {
      // Post to backend API
      await api.post('/customers', submissionData);
      toast.success('Borrower registered successfully in DB!');
      handleClear();
    } catch (err) {
      console.warn('API post failed, saving to LocalStorage fallback', err);
      // Fallback
      const local = localStorage.getItem(STORAGE_KEY);
      const list = local ? JSON.parse(local) : [];
      const newBorrower = {
        id: borrowerId, // localStorage ID key is id
        ...submissionData
      };
      list.push(newBorrower);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
      toast.success('Borrower registered successfully (Local Storage)!');
      handleClear();
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      <PageHeader
        title="New Borrower Registration"
        subtitle="Add a new borrower or client to the database."
        icon={User}
      />

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        {/* Left Column: Photo Upload card */}
        <div className="lg:col-span-1 space-y-6">
          <Card className="p-6 text-center">
            <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-4">Borrower Photo</h4>
            <div className="flex flex-col items-center gap-4">
              <div className="w-32 h-32 rounded-full border-2 border-dashed border-gray-300 flex items-center justify-center overflow-hidden bg-gray-50 relative group">
                {formData.photo ? (
                  <img src={formData.photo} alt="Borrower" className="w-full h-full object-cover" />
                ) : (
                  <User size={48} className="text-gray-300" />
                )}
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer">
                  <Upload size={20} className="text-white" />
                </div>
              </div>
              <input
                type="file"
                ref={fileInputRef}
                accept="image/*"
                onChange={handlePhotoUpload}
                className="hidden"
                id="photo-upload-input"
              />
              <Button
                variant="secondary"
                size="sm"
                onClick={() => fileInputRef.current?.click()}
                icon={Upload}
              >
                Upload Photo
              </Button>
            </div>
          </Card>
        </div>

        {/* Right Column: Form Inputs */}
        <div className="lg:col-span-3">
          <Card className="p-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              
              {/* Form Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <Input
                  label="Borrower ID"
                  disabled
                  value={borrowerId}
                  className="font-bold text-gray-800 bg-gray-50"
                />

                <Input
                  label="Borrower Name"
                  name="customerName"
                  required
                  value={formData.customerName}
                  onChange={handleInputChange}
                  placeholder="ENTER FULL NAME"
                />

                <Input
                  label="Guardian / Father Name"
                  name="guardian"
                  required
                  value={formData.guardian}
                  onChange={handleInputChange}
                  placeholder="ENTER GUARDIAN NAME"
                />

                <Input
                  label="Mobile Number"
                  name="mobileNumber"
                  required
                  maxLength={10}
                  value={formData.mobileNumber}
                  onChange={handleInputChange}
                  placeholder="ENTER 10 DIGIT MOBILE"
                />

                <Input
                  label="Alternate Number"
                  name="alternateNumber"
                  maxLength={10}
                  value={formData.alternateNumber}
                  onChange={handleInputChange}
                  placeholder="ALTERNATE MOBILE"
                />

                <Input
                  label="Date of Birth"
                  name="dob"
                  type="date"
                  value={formData.dob}
                  onChange={handleInputChange}
                />

                <Input
                  label="Age"
                  name="age"
                  type="number"
                  disabled
                  value={formData.age}
                  className="bg-gray-50 font-semibold"
                />

                <Select
                  label="Gender"
                  name="gender"
                  value={formData.gender}
                  onChange={handleInputChange}
                >
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </Select>

                <Input
                  label="Aadhaar Number"
                  name="aadhaarNo"
                  maxLength={12}
                  value={formData.aadhaarNo}
                  onChange={handleInputChange}
                  placeholder="12 DIGIT AADHAAR"
                />

                <Input
                  label="PAN Number (Optional)"
                  name="panNo"
                  maxLength={10}
                  value={formData.panNo}
                  onChange={handleInputChange}
                  placeholder="10 DIGIT PAN"
                />

                <Input
                  label="Occupation"
                  name="occupation"
                  value={formData.occupation}
                  onChange={handleInputChange}
                  placeholder="e.g. BUSINESS"
                />

                <Input
                  label="Monthly Income (₹)"
                  name="monthlyIncome"
                  type="number"
                  value={formData.monthlyIncome}
                  onChange={handleInputChange}
                  placeholder="e.g. 25000"
                />

                <Select
                  label="Branch"
                  name="branch"
                  value={formData.branch}
                  onChange={handleInputChange}
                >
                  {BRANCHES.map(b => <option key={b} value={b}>{b}</option>)}
                </Select>

                <Input
                  label="Member ID (Optional)"
                  name="memberId"
                  value={formData.memberId}
                  onChange={handleInputChange}
                  placeholder="e.g. MEM-123"
                />

                <Select
                  label="Status"
                  name="status"
                  value={formData.status}
                  onChange={handleInputChange}
                >
                  <option value="Active">Active</option>
                  <option value="Inactive">Inactive</option>
                </Select>
              </div>

              {/* Address details */}
              <div className="border-t border-gray-100 pt-4 space-y-4">
                <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider">Address Details</h4>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <Input
                    label="Door / Street"
                    name="doorNo"
                    required
                    value={formData.doorNo}
                    onChange={handleInputChange}
                    placeholder="DOOR / STREET"
                    containerClassName="md:col-span-2"
                  />
                  <Input
                    label="Area"
                    name="area"
                    required
                    value={formData.area}
                    onChange={handleInputChange}
                    placeholder="AREA"
                  />
                  <Input
                    label="City / Town"
                    name="city"
                    required
                    value={formData.city}
                    onChange={handleInputChange}
                    placeholder="CITY"
                  />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input
                    label="Permanent Address (Auto)"
                    disabled
                    value={formData.permanentAddress}
                    className="bg-gray-50"
                  />
                  <Input
                    label="Temporary Address"
                    name="temporaryAddress"
                    value={formData.temporaryAddress}
                    onChange={handleInputChange}
                    placeholder="ENTER TEMPORARY ADDRESS"
                  />
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex justify-end gap-3 border-t border-gray-100 pt-5">
                <Button
                  type="button"
                  variant="secondary"
                  onClick={handleClear}
                  icon={RefreshCw}
                >
                  Reset Form
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  loading={loading}
                  icon={Save}
                >
                  Save Borrower
                </Button>
              </div>

            </form>
          </Card>
        </div>

      </div>
    </div>
  );
};

export default NewBorrower;
