import { useState, useEffect } from 'react';
import { ShieldCheck, Search, ShieldAlert, Award, Calendar, RefreshCw } from 'lucide-react';
import toast from 'react-hot-toast';
import api from '../../../services/api';
import PageHeader from '../../../components/ui/PageHeader';
import Card from '../../../components/ui/Card';
import Input from '../../../components/ui/Input';
import Button from '../../../components/ui/Button';
import DataTable from '../../../components/ui/DataTable';
import { TD, TR } from '../../../components/ui/Table';

const STORAGE_KEY = 'belwin_customers';
const LOG_KEY = 'belwin_cibil_history';

const CIBILCheck = () => {
  const [borrowers, setBorrowers] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBorrower, setSelectedBorrower] = useState(null);
  
  const [loading, setLoading] = useState(false);
  const [score, setScore] = useState(null);
  const [eligibility, setEligibility] = useState('');
  const [checkDate] = useState(new Date().toISOString().split('T')[0]);
  const [remarks, setRemarks] = useState('');
  const [history, setHistory] = useState([]);

  // Fetch borrowers
  const fetchBorrowers = async () => {
    try {
      const res = await api.get('/customers');
      setBorrowers(res.data.customers || res.data || []);
    } catch (err) {
      console.warn('API customer load failed, loading from LocalStorage fallback');
      const local = localStorage.getItem(STORAGE_KEY);
      setBorrowers(local ? JSON.parse(local) : []);
    }
  };

  const loadHistory = () => {
    const local = localStorage.getItem(LOG_KEY);
    setHistory(local ? JSON.parse(local) : []);
  };

  useEffect(() => {
    fetchBorrowers();
    loadHistory();
  }, []);

  const handleSelectBorrower = (borrower) => {
    setSelectedBorrower(borrower);
    setSearchQuery('');
    setScore(borrower.cibilScore || null);
    setEligibility(borrower.loanEligibility || '');
    setRemarks(borrower.cibilRemarks || '');
  };

  const handleCheckCIBIL = () => {
    if (!selectedBorrower) return;
    setLoading(true);

    setTimeout(() => {
      // Deterministic pseudo-random score using the mobile number/ID hash
      const identVal = selectedBorrower.mobileNumber || '750';
      let sum = 0;
      for (let i = 0; i < identVal.length; i++) sum += identVal.charCodeAt(i);
      const computedScore = 600 + (sum % 250); // score range 600-850

      let eligMsg = '';
      if (computedScore >= 750) eligMsg = 'ELIGIBLE - PLATINUM LOAN OFFERS (UP TO ₹10 LAKHS)';
      else if (computedScore >= 700) eligMsg = 'ELIGIBLE - GOLD LOAN OFFERS (UP TO ₹5 LAKHS)';
      else if (computedScore >= 620) eligMsg = 'ELIGIBLE - SILVER LOAN OFFERS (UP TO ₹2 LAKHS)';
      else eligMsg = 'NOT ELIGIBLE - HIGH RISK RATING';

      setScore(computedScore);
      setEligibility(eligMsg);

      const checkRemarks = computedScore >= 700 ? 'EXCELLENT CREDIT STANDING' : 'MODERATE RISK RATING';
      setRemarks(checkRemarks);

      // Save log in history
      const logEntry = {
        _id: Date.now().toString(),
        customerId: selectedBorrower.customerId || selectedBorrower.id,
        customerName: selectedBorrower.customerName,
        panOrAadhaar: selectedBorrower.panNumber || selectedBorrower.panNo || selectedBorrower.aadhaarNumber || selectedBorrower.aadhaarNo || 'N/A',
        score: computedScore,
        eligibility: eligMsg,
        checkDate: checkDate,
        remarks: checkRemarks
      };

      const updatedHistory = [logEntry, ...history];
      localStorage.setItem(LOG_KEY, JSON.stringify(updatedHistory));
      setHistory(updatedHistory);

      // Save to local storage database
      const local = localStorage.getItem(STORAGE_KEY);
      const list = local ? JSON.parse(local) : [];
      const updatedList = list.map(b => {
        const idMatch = selectedBorrower.id ? b.id === selectedBorrower.id : b._id === selectedBorrower._id;
        if (idMatch) {
          return {
            ...b,
            cibilScore: computedScore,
            loanEligibility: eligMsg,
            cibilRemarks: checkRemarks,
            cibilCheckDate: checkDate
          };
        }
        return b;
      });
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedList));

      toast.success('CIBIL inquiry completed successfully!');
      setLoading(false);
    }, 1500);
  };

  const getScoreColor = (cibil) => {
    if (!cibil) return 'text-gray-400';
    if (cibil >= 750) return 'text-green-600';
    if (cibil >= 700) return 'text-emerald-500';
    if (cibil >= 620) return 'text-amber-500';
    return 'text-red-500';
  };

  const getScoreGaugeAngle = (cibil) => {
    if (!cibil) return 0;
    // Map score range 300-900 to gauge angle range -90deg to +90deg
    const clamped = Math.max(300, Math.min(900, cibil));
    const pct = (clamped - 300) / 600;
    return -90 + pct * 180;
  };

  // Filter query
  const filteredBorrowers = searchQuery.trim() !== ''
    ? borrowers.filter(b =>
        b.customerName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        b.mobileNumber?.includes(searchQuery) ||
        (b.customerId || b.id)?.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <PageHeader
        title="CIBIL Inquiry & Scoring"
        subtitle="Query and simulate borrower credit score and loan eligibility limits."
        icon={ShieldCheck}
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        
        {/* Borrower search and select */}
        <div className="lg:col-span-1 space-y-6">
          <Card className="p-5">
            <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">Select Borrower</h4>
            
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
                <Search size={16} />
              </span>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search name, ID or mobile..."
                className="w-full pl-9 pr-4 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-green-500 focus:ring-1 focus:ring-green-500 bg-gray-50"
              />
            </div>

            {filteredBorrowers.length > 0 && (
              <div className="mt-2 border border-gray-100 bg-white rounded-xl shadow-lg max-h-60 overflow-y-auto divide-y divide-gray-50">
                {filteredBorrowers.map(b => (
                  <button
                    key={b._id || b.id}
                    onClick={() => handleSelectBorrower(b)}
                    className="w-full text-left px-4 py-2.5 hover:bg-green-50 transition-colors flex flex-col gap-0.5 cursor-pointer"
                  >
                    <span className="font-bold text-sm text-gray-900">{b.customerName}</span>
                    <span className="text-xs text-gray-500 font-medium">ID: {b.customerId || b.id} · Mob: {b.mobileNumber}</span>
                  </button>
                ))}
              </div>
            )}

            {selectedBorrower ? (
              <div className="mt-4 p-4 rounded-2xl bg-green-50/50 border border-green-100 flex flex-col gap-2.5 animate-fade-in">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-green-600 flex items-center justify-center text-white font-bold">
                    {selectedBorrower.customerName.charAt(0)}
                  </div>
                  <div>
                    <h5 className="font-bold text-gray-900 text-sm">{selectedBorrower.customerName}</h5>
                    <p className="text-xs text-gray-500">ID: {selectedBorrower.customerId || selectedBorrower.id}</p>
                  </div>
                </div>
                <div className="text-xs space-y-1 text-gray-600 border-t border-green-100/50 pt-2 font-medium">
                  <p>PAN: {selectedBorrower.panNumber || selectedBorrower.panNo || 'N/A'}</p>
                  <p>Aadhaar: {selectedBorrower.aadhaarNumber || selectedBorrower.aadhaarNo || 'N/A'}</p>
                  <p>Mobile: {selectedBorrower.mobileNumber}</p>
                </div>
                <Button
                  onClick={handleCheckCIBIL}
                  loading={loading}
                  variant="primary"
                  className="w-full text-xs font-bold mt-2"
                  icon={ShieldCheck}
                >
                  Query Credit Rating
                </Button>
              </div>
            ) : (
              <div className="mt-4 p-6 rounded-2xl bg-gray-50 border border-dashed border-gray-200 text-center text-xs text-gray-400 font-medium">
                No borrower selected yet.
              </div>
            )}
          </Card>
        </div>

        {/* CIBIL Score gauge card */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="p-6 flex flex-col items-center justify-center text-center relative overflow-hidden">
            
            {score ? (
              <div className="space-y-6 w-full max-w-sm flex flex-col items-center">
                
                {/* SVG Gauge */}
                <div className="relative w-48 h-28 flex items-center justify-center">
                  <svg width="180" height="90" viewBox="0 0 180 90" className="overflow-visible">
                    {/* Background track */}
                    <path
                      d="M10 90 A80 80 0 0 1 170 90"
                      fill="none"
                      stroke="#f1f5f9"
                      strokeWidth="16"
                      strokeLinecap="round"
                    />
                    {/* Gauge segments (gradient represented in track path) */}
                    <path
                      d="M10 90 A80 80 0 0 1 170 90"
                      fill="none"
                      stroke="url(#gauge-gradient)"
                      strokeWidth="16"
                      strokeLinecap="round"
                    />
                    
                    <defs>
                      <linearGradient id="gauge-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#ef4444" /> {/* Poor */}
                        <stop offset="50%" stopColor="#f59e0b" /> {/* Good */}
                        <stop offset="100%" stopColor="#16a34a" /> {/* Excellent */}
                      </linearGradient>
                    </defs>

                    {/* Indicator needle */}
                    <g transform={`translate(90, 90) rotate(${getScoreGaugeAngle(score)})`}>
                      <line x1="0" y1="0" x2="0" y2="-75" stroke="#1e293b" strokeWidth="3" strokeLinecap="round" />
                      <circle cx="0" cy="0" r="6" fill="#1e293b" />
                    </g>
                  </svg>

                  {/* Absolute Score Display */}
                  <div className="absolute bottom-0 text-center">
                    <h2 className={`text-4xl font-black ${getScoreColor(score)}`}>{score}</h2>
                    <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">CIBIL SCORE</p>
                  </div>
                </div>

                {/* Score Remarks & Eligibility */}
                <div className="w-full text-center space-y-2 border-t border-gray-100 pt-4">
                  <h3 className="font-bold text-gray-900 text-sm flex items-center justify-center gap-1.5">
                    <Award size={16} className="text-green-600" />
                    {remarks}
                  </h3>
                  <div className="p-3 bg-green-50 rounded-xl border border-green-100 text-xs font-bold text-green-700 tracking-wide">
                    {eligibility}
                  </div>
                  <p className="text-[10px] text-gray-400 font-semibold flex items-center justify-center gap-1"><Calendar size={11} /> Checked on: {checkDate}</p>
                </div>

              </div>
            ) : (
              <div className="py-12 flex flex-col items-center gap-3">
                <div className="w-16 h-16 rounded-full bg-blue-50 flex items-center justify-center text-blue-600">
                  <ShieldAlert size={28} />
                </div>
                <h3 className="font-bold text-gray-900">Score Display Awaiting Inquiry</h3>
                <p className="text-xs text-gray-500 max-w-xs font-medium">Select a borrower and click "Query Credit Rating" to view their score and loan limits.</p>
              </div>
            )}

          </Card>
        </div>

      </div>

      {/* Inquiry Logs */}
      <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-4">Inquiry History Log</h3>
      <DataTable
        headers={[
          'Date',
          'Borrower ID',
          'Name',
          'PAN / Aadhaar',
          'CIBIL Score',
          'Eligibility Status',
          'Remarks'
        ]}
        data={history}
        renderRow={(h) => (
          <TR key={h._id}>
            <TD className="text-gray-500 text-xs font-semibold">{h.checkDate}</TD>
            <TD className="font-bold text-gray-800 text-xs">{h.customerId}</TD>
            <TD className="font-semibold text-xs">{h.customerName}</TD>
            <TD className="font-mono text-xs">{h.panOrAadhaar}</TD>
            <TD className={`font-bold text-xs ${getScoreColor(h.score)}`}>{h.score}</TD>
            <TD className="text-xs font-semibold text-green-700">{h.eligibility}</TD>
            <TD className="text-xs">{h.remarks}</TD>
          </TR>
        )}
      />

    </div>
  );
};

export default CIBILCheck;
