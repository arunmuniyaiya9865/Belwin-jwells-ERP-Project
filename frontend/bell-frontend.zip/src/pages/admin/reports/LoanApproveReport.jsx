import { useState, useEffect } from 'react';
import { FileText, Filter, Download } from 'lucide-react';
import PageHeader from '../../../components/ui/PageHeader';
import Card from '../../../components/ui/Card';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';
import DataTable from '../../../components/ui/DataTable';
import { TD, TR } from '../../../components/ui/Table';

const LoanApproveReport = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  
  const [filters, setFilters] = useState({
    loanNumber: '',
    borrowerName: '',
    branch: '',
    approvedBy: '',
    date: ''
  });

  const fetchData = async () => {
    setLoading(true);
    setTimeout(() => {
      setData([
        { _id: '1', loanNo: 'LN-002', borrower: 'Charlie Davis', approvedAmount: '150000', approvalDate: '2023-10-18', approvedBy: 'Admin', status: 'Approved' }
      ]);
      setLoading(false);
    }, 500);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleFilter = (e) => {
    e.preventDefault();
    fetchData();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 animate-fade-in">
      <PageHeader 
        title="Loan Approve Report" 
        subtitle="Report of all approved loans." 
        icon={FileText} 
        actions={<Button variant="secondary" icon={Download}>Export PDF</Button>}
      />
      
      <Card className="p-6 mb-6 shadow-sm border border-gray-100">
        <form onSubmit={handleFilter} className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 items-end">
          <Input label="Loan Number" value={filters.loanNumber} onChange={e => setFilters({...filters, loanNumber: e.target.value})} placeholder="e.g. LN-002" />
          <Input label="Borrower Name" value={filters.borrowerName} onChange={e => setFilters({...filters, borrowerName: e.target.value})} placeholder="Search..." />
          <Select label="Branch" value={filters.branch} onChange={e => setFilters({...filters, branch: e.target.value})}>
            <option value="">All Branches</option>
            <option value="Head Office">Head Office</option>
          </Select>
          <Input label="Approved By" value={filters.approvedBy} onChange={e => setFilters({...filters, approvedBy: e.target.value})} placeholder="Search..." />
          <Input label="Date" type="date" value={filters.date} onChange={e => setFilters({...filters, date: e.target.value})} />
          <div className="lg:col-span-5 flex justify-end">
             <Button type="submit" variant="primary" icon={Filter}>Apply Filters</Button>
          </div>
        </form>
      </Card>

      <DataTable
        headers={['Loan No', 'Borrower', 'Approved Amount', 'Approval Date', 'Approved By', 'Status']}
        data={data}
        loading={loading}
        renderRow={(item) => (
          <TR key={item._id}>
            <TD className="font-bold text-gray-800">{item.loanNo}</TD>
            <TD className="font-semibold text-gray-700">{item.borrower}</TD>
            <TD className="font-bold text-green-600">₹{item.approvedAmount}</TD>
            <TD>{item.approvalDate}</TD>
            <TD className="text-gray-600">{item.approvedBy}</TD>
            <TD><span className={`px-2 py-1 rounded-md text-xs font-medium ${item.status === 'Approved' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'}`}>{item.status}</span></TD>
          </TR>
        )}
      />
    </div>
  );
};
export default LoanApproveReport;
