import { useState, useEffect } from 'react';
import { FileText, Filter, Download } from 'lucide-react';
import PageHeader from '../../../components/ui/PageHeader';
import Card from '../../../components/ui/Card';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';
import DataTable from '../../../components/ui/DataTable';
import { TD, TR } from '../../../components/ui/Table';

const LoanDueReport = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  
  const [filters, setFilters] = useState({
    borrowerName: '',
    branch: '',
    dueDate: ''
  });

  const fetchData = async () => {
    setLoading(true);
    setTimeout(() => {
      setData([
        { _id: '1', loanNo: 'LN-003', borrower: 'Diana Prince', dueDate: '2023-11-01', emiAmount: '5000', dueAmount: '5000', daysDue: '0' }
      ]);
      setLoading(false);
    }, 500);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleFilter = (e) => {
    e.preventDefault();
    fetchData();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 animate-fade-in">
      <PageHeader 
        title="Loan Due Report" 
        subtitle="Loans with upcoming or current due dates." 
        icon={FileText} 
        actions={<Button variant="secondary" icon={Download}>Export PDF</Button>}
      />
      
      <Card className="p-6 mb-6 shadow-sm border border-gray-100">
        <form onSubmit={handleFilter} className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
          <Input label="Borrower Name" value={filters.borrowerName} onChange={e => setFilters({...filters, borrowerName: e.target.value})} placeholder="Search..." />
          <Select label="Branch" value={filters.branch} onChange={e => setFilters({...filters, branch: e.target.value})}>
            <option value="">All Branches</option>
            <option value="Head Office">Head Office</option>
          </Select>
          <Input label="Due Date" type="date" value={filters.dueDate} onChange={e => setFilters({...filters, dueDate: e.target.value})} />
          <div className="md:col-span-3 flex justify-end">
             <Button type="submit" variant="primary" icon={Filter}>Apply Filters</Button>
          </div>
        </form>
      </Card>

      <DataTable
        headers={['Loan No', 'Borrower', 'Due Date', 'EMI Amount', 'Due Amount', 'Days Due']}
        data={data}
        loading={loading}
        renderRow={(item) => (
          <TR key={item._id}>
            <TD className="font-bold text-gray-800">{item.loanNo}</TD>
            <TD className="font-semibold text-gray-700">{item.borrower}</TD>
            <TD className="text-red-500 font-medium">{item.dueDate}</TD>
            <TD className="font-medium text-gray-800">₹{item.emiAmount}</TD>
            <TD className="font-bold text-red-600">₹{item.dueAmount}</TD>
            <TD><span className="px-2 py-1 rounded-md text-xs font-medium bg-yellow-100 text-yellow-700">{item.daysDue} Days</span></TD>
          </TR>
        )}
      />
    </div>
  );
};
export default LoanDueReport;
