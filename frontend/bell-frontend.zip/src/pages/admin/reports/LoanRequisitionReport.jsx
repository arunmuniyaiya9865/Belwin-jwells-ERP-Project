import { useState, useEffect } from 'react';
import { FileText, Filter, Download } from 'lucide-react';
import PageHeader from '../../../components/ui/PageHeader';
import Card from '../../../components/ui/Card';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';
import DataTable from '../../../components/ui/DataTable';
import { TD, TR } from '../../../components/ui/Table';

const LoanRequisitionReport = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  
  const [filters, setFilters] = useState({
    applicationNo: '',
    borrowerName: '',
    branch: '',
    status: '',
    date: ''
  });

  const fetchData = async () => {
    setLoading(true);
    setTimeout(() => {
      setData([
        { _id: '1', appNo: 'APP-001', borrower: 'Bob Johnson', loanType: 'Personal Loan', reqAmount: '200000', appliedDate: '2023-10-15', status: 'Pending' }
      ]);
      setLoading(false);
    }, 500);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleFilter = (e) => {
    e.preventDefault();
    fetchData();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 animate-fade-in">
      <PageHeader 
        title="Loan Requisition Report" 
        subtitle="Report of all loan applications." 
        icon={FileText} 
        actions={<Button variant="secondary" icon={Download}>Export PDF</Button>}
      />
      
      <Card className="p-6 mb-6 shadow-sm border border-gray-100">
        <form onSubmit={handleFilter} className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 items-end">
          <Input label="Application No" value={filters.applicationNo} onChange={e => setFilters({...filters, applicationNo: e.target.value})} placeholder="e.g. APP-001" />
          <Input label="Borrower Name" value={filters.borrowerName} onChange={e => setFilters({...filters, borrowerName: e.target.value})} placeholder="Search..." />
          <Select label="Branch" value={filters.branch} onChange={e => setFilters({...filters, branch: e.target.value})}>
            <option value="">All Branches</option>
            <option value="Head Office">Head Office</option>
          </Select>
          <Select label="Status" value={filters.status} onChange={e => setFilters({...filters, status: e.target.value})}>
            <option value="">All Statuses</option>
            <option value="Pending">Pending</option>
            <option value="Approved">Approved</option>
            <option value="Rejected">Rejected</option>
          </Select>
          <Input label="Date" type="date" value={filters.date} onChange={e => setFilters({...filters, date: e.target.value})} />
          <div className="lg:col-span-5 flex justify-end">
             <Button type="submit" variant="primary" icon={Filter}>Apply Filters</Button>
          </div>
        </form>
      </Card>

      <DataTable
        headers={['Application No', 'Borrower', 'Loan Type', 'Requested Amount', 'Applied Date', 'Status']}
        data={data}
        loading={loading}
        renderRow={(item) => (
          <TR key={item._id}>
            <TD className="font-bold text-gray-800">{item.appNo}</TD>
            <TD className="font-semibold text-gray-700">{item.borrower}</TD>
            <TD className="text-gray-600">{item.loanType}</TD>
            <TD className="font-bold text-blue-600">₹{item.reqAmount}</TD>
            <TD>{item.appliedDate}</TD>
            <TD><span className={`px-2 py-1 rounded-md text-xs font-medium ${item.status === 'Pending' ? 'bg-yellow-100 text-yellow-700' : 'bg-gray-100 text-gray-700'}`}>{item.status}</span></TD>
          </TR>
        )}
      />
    </div>
  );
};
export default LoanRequisitionReport;
