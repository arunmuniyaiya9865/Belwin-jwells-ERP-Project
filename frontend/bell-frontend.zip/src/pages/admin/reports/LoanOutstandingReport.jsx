import { useState, useEffect } from 'react';
import { FileText, Filter, Download } from 'lucide-react';
import PageHeader from '../../../components/ui/PageHeader';
import Card from '../../../components/ui/Card';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';
import DataTable from '../../../components/ui/DataTable';
import { TD, TR } from '../../../components/ui/Table';

const LoanOutstandingReport = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  
  const [filters, setFilters] = useState({
    borrowerName: '',
    branch: '',
    loanType: ''
  });

  const fetchData = async () => {
    setLoading(true);
    setTimeout(() => {
      setData([
        { _id: '1', loanNo: 'LN-005', borrower: 'Frank Miller', loanAmount: '500000', paidAmount: '100000', outstandingBalance: '400000', status: 'Active' }
      ]);
      setLoading(false);
    }, 500);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleFilter = (e) => {
    e.preventDefault();
    fetchData();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 animate-fade-in">
      <PageHeader 
        title="Loan Outstanding Report" 
        subtitle="Loans that currently have a pending balance." 
        icon={FileText} 
        actions={<Button variant="secondary" icon={Download}>Export PDF</Button>}
      />
      
      <Card className="p-6 mb-6 shadow-sm border border-gray-100">
        <form onSubmit={handleFilter} className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
          <Input label="Borrower Name" value={filters.borrowerName} onChange={e => setFilters({...filters, borrowerName: e.target.value})} placeholder="Search..." />
          <Select label="Branch" value={filters.branch} onChange={e => setFilters({...filters, branch: e.target.value})}>
            <option value="">All Branches</option>
            <option value="Head Office">Head Office</option>
          </Select>
          <Select label="Loan Type" value={filters.loanType} onChange={e => setFilters({...filters, loanType: e.target.value})}>
            <option value="">All Types</option>
            <option value="Personal Loan">Personal Loan</option>
            <option value="Gold Loan">Gold Loan</option>
            <option value="Vehicle Loan">Vehicle Loan</option>
          </Select>
          <div className="md:col-span-3 flex justify-end">
             <Button type="submit" variant="primary" icon={Filter}>Apply Filters</Button>
          </div>
        </form>
      </Card>

      <DataTable
        headers={['Loan No', 'Borrower', 'Loan Amount', 'Paid Amount', 'Outstanding Balance', 'Status']}
        data={data}
        loading={loading}
        renderRow={(item) => (
          <TR key={item._id}>
            <TD className="font-bold text-gray-800">{item.loanNo}</TD>
            <TD className="font-semibold text-gray-700">{item.borrower}</TD>
            <TD className="font-medium">₹{item.loanAmount}</TD>
            <TD className="text-green-600 font-medium">₹{item.paidAmount}</TD>
            <TD className="font-bold text-orange-600">₹{item.outstandingBalance}</TD>
            <TD><span className={`px-2 py-1 rounded-md text-xs font-medium ${item.status === 'Active' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'}`}>{item.status}</span></TD>
          </TR>
        )}
      />
    </div>
  );
};
export default LoanOutstandingReport;
