import { useState, useEffect } from 'react';
import { FileText, Filter, Download } from 'lucide-react';
import PageHeader from '../../../components/ui/PageHeader';
import Card from '../../../components/ui/Card';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';
import DataTable from '../../../components/ui/DataTable';
import { TD, TR } from '../../../components/ui/Table';

const LoanEmiCollectionReport = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  
  const [filters, setFilters] = useState({
    collectionDate: '',
    borrowerName: '',
    branch: '',
    paymentMode: ''
  });

  const fetchData = async () => {
    setLoading(true);
    setTimeout(() => {
      setData([
        { _id: '1', receiptNo: 'REC-001', loanNo: 'LN-006', borrower: 'Grace Lee', emiAmount: '8500', collectionDate: '2023-11-05', paymentMode: 'UPI', collectedBy: 'Admin' }
      ]);
      setLoading(false);
    }, 500);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleFilter = (e) => {
    e.preventDefault();
    fetchData();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 animate-fade-in">
      <PageHeader 
        title="Loan EMI Collection Report" 
        subtitle="Report of EMI collections." 
        icon={FileText} 
        actions={<Button variant="secondary" icon={Download}>Export PDF</Button>}
      />
      
      <Card className="p-6 mb-6 shadow-sm border border-gray-100">
        <form onSubmit={handleFilter} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
          <Input label="Collection Date" type="date" value={filters.collectionDate} onChange={e => setFilters({...filters, collectionDate: e.target.value})} />
          <Input label="Borrower Name" value={filters.borrowerName} onChange={e => setFilters({...filters, borrowerName: e.target.value})} placeholder="Search..." />
          <Select label="Branch" value={filters.branch} onChange={e => setFilters({...filters, branch: e.target.value})}>
            <option value="">All Branches</option>
            <option value="Head Office">Head Office</option>
          </Select>
          <Select label="Payment Mode" value={filters.paymentMode} onChange={e => setFilters({...filters, paymentMode: e.target.value})}>
            <option value="">All Modes</option>
            <option value="Cash">Cash</option>
            <option value="UPI">UPI</option>
            <option value="Bank Transfer">Bank Transfer</option>
          </Select>
          <div className="lg:col-span-4 flex justify-end">
             <Button type="submit" variant="primary" icon={Filter}>Apply Filters</Button>
          </div>
        </form>
      </Card>

      <DataTable
        headers={['Receipt No', 'Loan No', 'Borrower', 'EMI Amount', 'Collection Date', 'Payment Mode', 'Collected By']}
        data={data}
        loading={loading}
        renderRow={(item) => (
          <TR key={item._id}>
            <TD className="font-bold text-gray-800">{item.receiptNo}</TD>
            <TD className="font-semibold text-gray-600">{item.loanNo}</TD>
            <TD className="font-semibold text-gray-700">{item.borrower}</TD>
            <TD className="font-bold text-green-600">₹{item.emiAmount}</TD>
            <TD>{item.collectionDate}</TD>
            <TD><span className="px-2 py-1 rounded-md text-xs font-medium bg-blue-50 text-blue-600">{item.paymentMode}</span></TD>
            <TD className="text-gray-500">{item.collectedBy}</TD>
          </TR>
        )}
      />
    </div>
  );
};
export default LoanEmiCollectionReport;
