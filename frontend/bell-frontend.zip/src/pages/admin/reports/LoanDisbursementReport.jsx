import { useState, useEffect } from 'react';
import { FileText, Filter, Download } from 'lucide-react';
import PageHeader from '../../../components/ui/PageHeader';
import Card from '../../../components/ui/Card';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';
import DataTable from '../../../components/ui/DataTable';
import { TD, TR } from '../../../components/ui/Table';

const LoanDisbursementReport = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  
  const [filters, setFilters] = useState({
    loanNumber: '',
    borrowerName: '',
    branch: '',
    paymentMode: '',
    date: ''
  });

  const fetchData = async () => {
    setLoading(true);
    setTimeout(() => {
      setData([
        { _id: '1', loanNo: 'LN-002', borrower: 'Charlie Davis', disbursementDate: '2023-10-20', amount: '150000', paymentMode: 'Bank Transfer', transactionNo: 'TXN-987654321' }
      ]);
      setLoading(false);
    }, 500);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleFilter = (e) => {
    e.preventDefault();
    fetchData();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 animate-fade-in">
      <PageHeader 
        title="Loan Disbursement Report" 
        subtitle="Report of loans released to customers." 
        icon={FileText} 
        actions={<Button variant="secondary" icon={Download}>Export PDF</Button>}
      />
      
      <Card className="p-6 mb-6 shadow-sm border border-gray-100">
        <form onSubmit={handleFilter} className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 items-end">
          <Input label="Loan Number" value={filters.loanNumber} onChange={e => setFilters({...filters, loanNumber: e.target.value})} placeholder="e.g. LN-002" />
          <Input label="Borrower Name" value={filters.borrowerName} onChange={e => setFilters({...filters, borrowerName: e.target.value})} placeholder="Search..." />
          <Select label="Branch" value={filters.branch} onChange={e => setFilters({...filters, branch: e.target.value})}>
            <option value="">All Branches</option>
            <option value="Head Office">Head Office</option>
          </Select>
          <Select label="Payment Mode" value={filters.paymentMode} onChange={e => setFilters({...filters, paymentMode: e.target.value})}>
            <option value="">All Modes</option>
            <option value="Cash">Cash</option>
            <option value="Bank Transfer">Bank Transfer</option>
            <option value="Cheque">Cheque</option>
          </Select>
          <Input label="Date" type="date" value={filters.date} onChange={e => setFilters({...filters, date: e.target.value})} />
          <div className="lg:col-span-5 flex justify-end">
             <Button type="submit" variant="primary" icon={Filter}>Apply Filters</Button>
          </div>
        </form>
      </Card>

      <DataTable
        headers={['Loan No', 'Borrower', 'Disbursement Date', 'Amount', 'Payment Mode', 'Transaction No']}
        data={data}
        loading={loading}
        renderRow={(item) => (
          <TR key={item._id}>
            <TD className="font-bold text-gray-800">{item.loanNo}</TD>
            <TD className="font-semibold text-gray-700">{item.borrower}</TD>
            <TD>{item.disbursementDate}</TD>
            <TD className="font-bold text-green-600">₹{item.amount}</TD>
            <TD className="text-gray-600">{item.paymentMode}</TD>
            <TD className="font-mono text-sm text-gray-500">{item.transactionNo}</TD>
          </TR>
        )}
      />
    </div>
  );
};
export default LoanDisbursementReport;
