import { useState, useEffect } from 'react';
import { FileText, Filter, Download } from 'lucide-react';
import PageHeader from '../../../components/ui/PageHeader';
import Card from '../../../components/ui/Card';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';
import DataTable from '../../../components/ui/DataTable';
import { TD, TR } from '../../../components/ui/Table';

const LoanOverDueReport = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  
  const [filters, setFilters] = useState({
    borrowerName: '',
    branch: '',
    overdueDays: ''
  });

  const fetchData = async () => {
    setLoading(true);
    setTimeout(() => {
      setData([
        { _id: '1', loanNo: 'LN-004', borrower: 'Eve Torres', outstanding: '20000', overdueDays: '15', penalty: '500', status: 'Overdue' }
      ]);
      setLoading(false);
    }, 500);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleFilter = (e) => {
    e.preventDefault();
    fetchData();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 animate-fade-in">
      <PageHeader 
        title="Loan Over Due Report" 
        subtitle="Loans that have crossed their due date." 
        icon={FileText} 
        actions={<Button variant="secondary" icon={Download}>Export PDF</Button>}
      />
      
      <Card className="p-6 mb-6 shadow-sm border border-gray-100">
        <form onSubmit={handleFilter} className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
          <Input label="Borrower Name" value={filters.borrowerName} onChange={e => setFilters({...filters, borrowerName: e.target.value})} placeholder="Search..." />
          <Select label="Branch" value={filters.branch} onChange={e => setFilters({...filters, branch: e.target.value})}>
            <option value="">All Branches</option>
            <option value="Head Office">Head Office</option>
          </Select>
          <Input label="Overdue Days (>)" type="number" value={filters.overdueDays} onChange={e => setFilters({...filters, overdueDays: e.target.value})} placeholder="e.g. 10" />
          <div className="md:col-span-3 flex justify-end">
             <Button type="submit" variant="primary" icon={Filter}>Apply Filters</Button>
          </div>
        </form>
      </Card>

      <DataTable
        headers={['Loan No', 'Borrower', 'Outstanding', 'Overdue Days', 'Penalty', 'Status']}
        data={data}
        loading={loading}
        renderRow={(item) => (
          <TR key={item._id}>
            <TD className="font-bold text-gray-800">{item.loanNo}</TD>
            <TD className="font-semibold text-gray-700">{item.borrower}</TD>
            <TD className="font-bold text-orange-600">₹{item.outstanding}</TD>
            <TD className="text-red-600 font-bold">{item.overdueDays} Days</TD>
            <TD className="text-red-500 font-medium">₹{item.penalty}</TD>
            <TD><span className={`px-2 py-1 rounded-md text-xs font-medium ${item.status === 'Overdue' ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-700'}`}>{item.status}</span></TD>
          </TR>
        )}
      />
    </div>
  );
};
export default LoanOverDueReport;
