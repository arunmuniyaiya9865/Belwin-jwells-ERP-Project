import { useState, useEffect } from 'react';
import { Plus, Edit3, Trash2, ShieldAlert, Check, X, FileText, Search, ArrowLeft } from 'lucide-react';
import api from '../../../services/api';
import PageHeader from '../../../components/ui/PageHeader';
import Card from '../../../components/ui/Card';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';
import Badge from '../../../components/ui/Badge';
import DataTable from '../../../components/ui/DataTable';
import ConfirmDialog from '../../../components/ui/ConfirmDialog';
import { TD, TR } from '../../../components/ui/Table';

const STORAGE_KEY = 'bellwin_loan_schemes';

const LoanScheme = () => {
  const [schemes, setSchemes] = useState([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  
  // Modal states
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingScheme, setEditingScheme] = useState(null);
  const [formData, setFormData] = useState({
    schemeName: '',
    schemeCode: '',
    interestPercent: '',
    maxLoanPercent: '',
    tenureValue: '',
    tenureUnit: 'Months',
    processingFee: '',
    penaltyPercent: '',
    status: 'Active'
  });

  // Delete dialog state
  const [deleteId, setDeleteId] = useState(null);

  // Fetch schemes
  const fetchSchemes = async () => {
    setLoading(true);
    try {
      // Attempt to load from API
      const res = await api.get('/gold-schemes');
      setSchemes(res.data.schemes || res.data || []);
    } catch (err) {
      console.warn('API /gold-schemes not available, falling back to LocalStorage', err);
      const local = localStorage.getItem(STORAGE_KEY);
      if (local) {
        setSchemes(JSON.parse(local));
      } else {
        // Seed default schemes
        const defaults = [
          {
            _id: '1',
            schemeName: 'Super Saver Gold Loan',
            schemeCode: 'SSGL-01',
            interestPercent: 11.5,
            maxLoanPercent: 75,
            tenureValue: 12,
            tenureUnit: 'Months',
            processingFee: 500,
            penaltyPercent: 2,
            status: 'Active'
          },
          {
            _id: '2',
            schemeName: 'Short Term Quick Loan',
            schemeCode: 'STQL-02',
            interestPercent: 9.0,
            maxLoanPercent: 70,
            tenureValue: 180,
            tenureUnit: 'Days',
            processingFee: 250,
            penaltyPercent: 1.5,
            status: 'Active'
          }
        ];
        localStorage.setItem(STORAGE_KEY, JSON.stringify(defaults));
        setSchemes(defaults);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSchemes();
  }, []);

  const handleOpenAdd = () => {
    setEditingScheme(null);
    setFormData({
      schemeName: '',
      schemeCode: '',
      interestPercent: '',
      maxLoanPercent: '',
      tenureValue: '',
      tenureUnit: 'Months',
      processingFee: '',
      penaltyPercent: '',
      status: 'Active'
    });
    setIsFormOpen(true);
  };

  const handleOpenEdit = (scheme) => {
    setEditingScheme(scheme);
    setFormData({
      schemeName: scheme.schemeName || '',
      schemeCode: scheme.schemeCode || '',
      interestPercent: scheme.interestPercent || '',
      maxLoanPercent: scheme.maxLoanPercent || '',
      tenureValue: scheme.tenureValue || '',
      tenureUnit: scheme.tenureUnit || 'Months',
      processingFee: scheme.processingFee || '',
      penaltyPercent: scheme.penaltyPercent || '',
      status: scheme.status || 'Active'
    });
    setIsFormOpen(true);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    if (!formData.schemeName || !formData.schemeCode) return alert('Name and Code are required');

    setLoading(true);
    try {
      if (editingScheme) {
        // Update API
        try {
          await api.put(`/gold-schemes/${editingScheme._id}`, formData);
        } catch (apiErr) {
          // Fallback LocalStorage update
          const updated = schemes.map(s => s._id === editingScheme._id ? { ...s, ...formData } : s);
          localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
        }
      } else {
        // Create API
        try {
          await api.post('/gold-schemes', formData);
        } catch (apiErr) {
          // Fallback LocalStorage create
          const newScheme = {
            _id: Date.now().toString(),
            ...formData
          };
          const updated = [...schemes, newScheme];
          localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
        }
      }
      setIsFormOpen(false);
      fetchSchemes();
    } catch (err) {
      console.error(err);
      alert('Failed to save scheme');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    setLoading(true);
    try {
      try {
        await api.delete(`/gold-schemes/${deleteId}`);
      } catch (apiErr) {
        // Fallback LocalStorage delete
        const updated = schemes.filter(s => s._id !== deleteId);
        localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      }
      setDeleteId(null);
      fetchSchemes();
    } catch (err) {
      console.error(err);
      alert('Failed to delete scheme');
    } finally {
      setLoading(false);
    }
  };

  const filteredSchemes = schemes.filter(s =>
    s.schemeName?.toLowerCase().includes(search.toLowerCase()) ||
    s.schemeCode?.toLowerCase().includes(search.toLowerCase())
  );

  if (isFormOpen) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-6 animate-fade-in">
        <div className="flex items-center gap-4 mb-6">
          <button 
            onClick={() => setIsFormOpen(false)}
            className="p-2 text-gray-500 hover:text-green-600 hover:bg-green-50 rounded-xl transition-colors"
          >
            <ArrowLeft size={24} />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              {editingScheme ? 'Edit Loan Scheme' : 'Add New Loan Scheme'}
            </h1>
          </div>
        </div>

        <Card className="p-8 shadow-lg border border-gray-100">
          <form onSubmit={handleSave} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input
              label="Scheme Name"
              required
              value={formData.schemeName}
              onChange={(e) => setFormData({ ...formData, schemeName: e.target.value.toUpperCase() })}
              placeholder="e.g. SILVER SAVER SCHEME"
            />
            <Input
              label="Scheme Code"
              required
              value={formData.schemeCode}
              onChange={(e) => setFormData({ ...formData, schemeCode: e.target.value.toUpperCase() })}
              placeholder="e.g. SSS-01"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Input
              label="Interest Rate (% p.a.)"
              type="number"
              step="0.01"
              required
              value={formData.interestPercent}
              onChange={(e) => setFormData({ ...formData, interestPercent: parseFloat(e.target.value) || '' })}
              placeholder="e.g. 12"
            />
            <Input
              label="Maximum Loan %"
              type="number"
              required
              value={formData.maxLoanPercent}
              onChange={(e) => setFormData({ ...formData, maxLoanPercent: parseInt(e.target.value) || '' })}
              placeholder="e.g. 75"
            />
            <Input
              label="Processing Fee (₹)"
              type="number"
              required
              value={formData.processingFee}
              onChange={(e) => setFormData({ ...formData, processingFee: parseInt(e.target.value) || '' })}
              placeholder="e.g. 500"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Input
              label="Tenure Value"
              type="number"
              required
              value={formData.tenureValue}
              onChange={(e) => setFormData({ ...formData, tenureValue: parseInt(e.target.value) || '' })}
              placeholder="e.g. 12"
            />
            <Select
              label="Tenure Unit"
              value={formData.tenureUnit}
              onChange={(e) => setFormData({ ...formData, tenureUnit: e.target.value })}
            >
              <option value="Months">Months</option>
              <option value="Days">Days</option>
            </Select>
            <Input
              label="Penalty Rate (% p.a.)"
              type="number"
              step="0.01"
              required
              value={formData.penaltyPercent}
              onChange={(e) => setFormData({ ...formData, penaltyPercent: parseFloat(e.target.value) || '' })}
              placeholder="e.g. 2"
            />
          </div>

          <Select
            label="Scheme Status"
            value={formData.status}
            onChange={(e) => setFormData({ ...formData, status: e.target.value })}
          >
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
          </Select>
          
            <div className="flex items-center justify-end gap-4 pt-6 border-t border-gray-100 mt-6">
              <Button 
                type="button" 
                onClick={() => setIsFormOpen(false)} 
                variant="secondary"
                className="px-6 py-2.5"
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                variant="primary" 
                loading={loading}
                className="px-8 py-2.5 shadow-md hover:shadow-lg transition-all"
              >
                Save Scheme
              </Button>
            </div>
        </form>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 animate-fade-in">
      <PageHeader
        title="Loan Scheme Master"
        subtitle="Manage and configure active gold loan schemes, interest rules, and processing fee frameworks."
        icon={FileText}
        actions={
          <Button onClick={handleOpenAdd} icon={Plus} variant="primary">
            Add Scheme
          </Button>
        }
      />

      {/* Filter and Search Bar */}
      <Card className="p-4 mb-6 shadow-sm border border-gray-100">
        <div className="relative max-w-md">
          <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
            <Search size={16} />
          </span>
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search schemes by name or code..."
            className="w-full pl-9 pr-4 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-green-500 focus:ring-1 focus:ring-green-500 bg-gray-50"
          />
        </div>
      </Card>

      {/* Schemes List Table */}
      <DataTable
        headers={[
          'Scheme Code',
          'Scheme Name',
          'Interest %',
          'Max Loan %',
          'Tenure',
          'Proc. Fee',
          'Penalty %',
          'Status',
          'Actions'
        ]}
        data={filteredSchemes}
        loading={loading}
        renderRow={(scheme) => (
          <TR key={scheme._id}>
            <TD className="font-bold text-gray-800">{scheme.schemeCode}</TD>
            <TD className="font-semibold">{scheme.schemeName}</TD>
            <TD className="font-semibold text-green-700">{scheme.interestPercent}%</TD>
            <TD>{scheme.maxLoanPercent}%</TD>
            <TD>{scheme.tenureValue} {scheme.tenureUnit}</TD>
            <TD>₹{scheme.processingFee}</TD>
            <TD className="text-red-500">{scheme.penaltyPercent}%</TD>
            <TD>
              <Badge variant={scheme.status === 'Active' ? 'success' : 'danger'}>
                {scheme.status}
              </Badge>
            </TD>
            <TD>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleOpenEdit(scheme)}
                  className="p-1.5 text-gray-500 hover:text-green-600 hover:bg-green-50 rounded-lg cursor-pointer transition-colors"
                  title="Edit Scheme"
                >
                  <Edit3 size={15} />
                </button>
                <button
                  onClick={() => setDeleteId(scheme._id)}
                  className="p-1.5 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-lg cursor-pointer transition-colors"
                  title="Delete Scheme"
                >
                  <Trash2 size={15} />
                </button>
              </div>
            </TD>
          </TR>
        )}
      />

      {/* Add / Edit Modal */}
      

      {/* Delete Confirmation */}
      <ConfirmDialog
        isOpen={!!deleteId}
        onClose={() => setDeleteId(null)}
        onConfirm={handleDelete}
        title="Delete Loan Scheme"
        description="Are you sure you want to delete this scheme? This action cannot be undone."
        confirmText="Delete"
        cancelText="Cancel"
        variant="danger"
      />
    </div>
  );
};

export default LoanScheme;
