import { useState, useEffect } from 'react';
import { Plus, Edit3, Trash2, Search, Store, ArrowLeft } from 'lucide-react';
import api from '../../../services/api';
import PageHeader from '../../../components/ui/PageHeader';
import Card from '../../../components/ui/Card';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';
import Badge from '../../../components/ui/Badge';
import DataTable from '../../../components/ui/DataTable';
import ConfirmDialog from '../../../components/ui/ConfirmDialog';
import { TD, TR } from '../../../components/ui/Table';

const STORAGE_KEY = 'bellwin_dealers';

const DealerMaster = () => {
  const [dealers, setDealers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  
  // Modal states
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingDealer, setEditingDealer] = useState(null);
  const [formData, setFormData] = useState({
    dealerName: '',
    dealerCode: '',
    contactPerson: '',
    mobileNumber: '',
    address: '',
    gstNumber: '',
    status: 'Active'
  });

  // Delete dialog state
  const [deleteId, setDeleteId] = useState(null);

  // Fetch dealers
  const fetchDealers = async () => {
    setLoading(true);
    try {
      const res = await api.get('/loan-config/dealer');
      setDealers(res.data.dealers || res.data || []);
    } catch (err) {
      console.warn('API dealer not available, falling back to LocalStorage', err);
      const local = localStorage.getItem(STORAGE_KEY);
      if (local) {
        setDealers(JSON.parse(local));
      } else {
        const defaults = [
          {
            _id: '1',
            dealerName: 'KALYAN JEWELLERS B2B',
            dealerCode: 'DLR-001',
            contactPerson: 'Ramesh Kalyan',
            mobileNumber: '9840123456',
            address: '100, T. Nagar Main Road, Chennai',
            gstNumber: '33AAAAA1111A1Z1',
            status: 'Active'
          },
          {
            _id: '2',
            dealerName: 'MALABAR GOLD SUPPLY',
            dealerCode: 'DLR-002',
            contactPerson: 'Suresh Menon',
            mobileNumber: '9840987654',
            address: '50, Cathedral Road, Chennai',
            gstNumber: '33BBBBB2222B2Z2',
            status: 'Active'
          }
        ];
        localStorage.setItem(STORAGE_KEY, JSON.stringify(defaults));
        setDealers(defaults);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDealers();
  }, []);

  const handleOpenAdd = () => {
    setEditingDealer(null);
    setFormData({
      dealerName: '',
      dealerCode: `DLR-${String(dealers.length + 1).padStart(3, '0')}`,
      contactPerson: '',
      mobileNumber: '',
      address: '',
      gstNumber: '',
      status: 'Active'
    });
    setIsFormOpen(true);
  };

  const handleOpenEdit = (dealer) => {
    setEditingDealer(dealer);
    setFormData({
      dealerName: dealer.dealerName || '',
      dealerCode: dealer.dealerCode || '',
      contactPerson: dealer.contactPerson || '',
      mobileNumber: dealer.mobileNumber || '',
      address: dealer.address || '',
      gstNumber: dealer.gstNumber || '',
      status: dealer.status || 'Active'
    });
    setIsFormOpen(true);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    if (!formData.dealerName || !formData.dealerCode) return alert('Name and Code are required');
    if (formData.mobileNumber && formData.mobileNumber.length !== 10) return alert('Mobile must be 10 digits');

    setLoading(true);
    try {
      if (editingDealer) {
        try {
          await api.put(`/loan-config/dealer/${editingDealer._id}`, formData);
        } catch (apiErr) {
          const updated = dealers.map(d => d._id === editingDealer._id ? { ...d, ...formData } : d);
          localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
        }
      } else {
        try {
          await api.post('/loan-config/dealer', formData);
        } catch (apiErr) {
          const newDealer = {
            _id: Date.now().toString(),
            ...formData
          };
          const updated = [...dealers, newDealer];
          localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
        }
      }
      setIsFormOpen(false);
      fetchDealers();
    } catch (err) {
      console.error(err);
      alert('Failed to save dealer');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    setLoading(true);
    try {
      try {
        await api.delete(`/loan-config/dealer/${deleteId}`);
      } catch (apiErr) {
        const updated = dealers.filter(d => d._id !== deleteId);
        localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      }
      setDeleteId(null);
      fetchDealers();
    } catch (err) {
      console.error(err);
      alert('Failed to delete dealer');
    } finally {
      setLoading(false);
    }
  };

  const filteredDealers = dealers.filter(d =>
    d.dealerName?.toLowerCase().includes(search.toLowerCase()) ||
    d.dealerCode?.toLowerCase().includes(search.toLowerCase()) ||
    d.contactPerson?.toLowerCase().includes(search.toLowerCase())
  );

  if (isFormOpen) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-6 animate-fade-in">
        <div className="flex items-center gap-4 mb-6">
          <button 
            onClick={() => setIsFormOpen(false)}
            className="p-2 text-gray-500 hover:text-green-600 hover:bg-green-50 rounded-xl transition-colors"
          >
            <ArrowLeft size={24} />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              {editingDealer ? 'Edit Dealer Master' : 'Add New Dealer'}
            </h1>
          </div>
        </div>

        <Card className="p-8 shadow-lg border border-gray-100">
          <form onSubmit={handleSave} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input
              label="Dealer Name"
              required
              value={formData.dealerName}
              onChange={(e) => setFormData({ ...formData, dealerName: e.target.value.toUpperCase() })}
              placeholder="e.g. KALYAN JEWELLERS B2B"
            />
            <Input
              label="Dealer Code"
              required
              disabled
              value={formData.dealerCode}
              onChange={(e) => setFormData({ ...formData, dealerCode: e.target.value.toUpperCase() })}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input
              label="Contact Person"
              required
              value={formData.contactPerson}
              onChange={(e) => setFormData({ ...formData, contactPerson: e.target.value.toUpperCase() })}
              placeholder="e.g. RAMESH KALYAN"
            />
            <Input
              label="Mobile Number"
              required
              maxLength={10}
              value={formData.mobileNumber}
              onChange={(e) => {
                const val = e.target.value;
                if (val === '' || /^[0-9]+$/.test(val)) {
                  setFormData({ ...formData, mobileNumber: val });
                }
              }}
              placeholder="e.g. 9840123456"
            />
          </div>

          <Input
            label="Address"
            value={formData.address}
            onChange={(e) => setFormData({ ...formData, address: e.target.value.toUpperCase() })}
            placeholder="e.g. 100, T. NAGAR MAIN ROAD, CHENNAI"
          />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input
              label="GST Number (Optional)"
              value={formData.gstNumber}
              onChange={(e) => setFormData({ ...formData, gstNumber: e.target.value.toUpperCase() })}
              placeholder="e.g. 33AAAAA1111A1Z1"
            />
            <Select
              label="Status"
              value={formData.status}
              onChange={(e) => setFormData({ ...formData, status: e.target.value })}
            >
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
            </Select>
          </div>
          
            <div className="flex items-center justify-end gap-4 pt-6 border-t border-gray-100 mt-6">
              <Button 
                type="button" 
                onClick={() => setIsFormOpen(false)} 
                variant="secondary"
                className="px-6 py-2.5"
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                variant="primary" 
                loading={loading}
                className="px-8 py-2.5 shadow-md hover:shadow-lg transition-all"
              >
                Save Dealer
              </Button>
            </div>
        </form>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 animate-fade-in">
      <PageHeader
        title="Dealer Master"
        subtitle="Manage details of corporate gold bullion dealers, scrap merchants, and business partners."
        icon={Store}
        actions={
          <Button onClick={handleOpenAdd} icon={Plus} variant="primary">
            Add Dealer
          </Button>
        }
      />

      <Card className="p-4 mb-6 shadow-sm border border-gray-100">
        <div className="relative max-w-md">
          <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
            <Search size={16} />
          </span>
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name, code or contact person..."
            className="w-full pl-9 pr-4 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-green-500 focus:ring-1 focus:ring-green-500 bg-gray-50"
          />
        </div>
      </Card>

      <DataTable
        headers={[
          'Dealer Code',
          'Dealer Name',
          'Contact Person',
          'Mobile Number',
          'GST Number',
          'Status',
          'Actions'
        ]}
        data={filteredDealers}
        loading={loading}
        renderRow={(dealer) => (
          <TR key={dealer._id}>
            <TD className="font-bold text-gray-800">{dealer.dealerCode}</TD>
            <TD className="font-semibold">{dealer.dealerName}</TD>
            <TD>{dealer.contactPerson}</TD>
            <TD>{dealer.mobileNumber}</TD>
            <TD className="font-mono text-xs">{dealer.gstNumber || 'N/A'}</TD>
            <TD>
              <Badge variant={dealer.status === 'Active' ? 'success' : 'danger'}>
                {dealer.status}
              </Badge>
            </TD>
            <TD>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleOpenEdit(dealer)}
                  className="p-1.5 text-gray-500 hover:text-green-600 hover:bg-green-50 rounded-lg cursor-pointer transition-colors"
                  title="Edit Dealer"
                >
                  <Edit3 size={15} />
                </button>
                <button
                  onClick={() => setDeleteId(dealer._id)}
                  className="p-1.5 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-lg cursor-pointer transition-colors"
                  title="Delete Dealer"
                >
                  <Trash2 size={15} />
                </button>
              </div>
            </TD>
          </TR>
        )}
      />

      

      <ConfirmDialog
        isOpen={!!deleteId}
        onClose={() => setDeleteId(null)}
        onConfirm={handleDelete}
        title="Delete Dealer"
        description="Are you sure you want to delete this dealer record? This action cannot be undone."
        confirmText="Delete"
        cancelText="Cancel"
        variant="danger"
      />
    </div>
  );
};

export default DealerMaster;
