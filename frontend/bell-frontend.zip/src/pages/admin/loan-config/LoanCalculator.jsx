import { useState, useEffect } from 'react';
import { Calculator, Calendar, DollarSign, Percent, TrendingUp } from 'lucide-react';
import PageHeader from '../../../components/ui/PageHeader';
import Card from '../../../components/ui/Card';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';

const LoanCalculator = () => {
  const [amount, setAmount] = useState(50000);
  const [interestRate, setInterestRate] = useState(12); // Annual rate
  const [periodType, setPeriodType] = useState('Months');
  const [duration, setDuration] = useState(12);
  const [calcMethod, setCalcMethod] = useState('Simple'); // 'EMI' or 'Simple'
  
  // Results
  const [processingFee, setProcessingFee] = useState(500);
  const [totalInterest, setTotalInterest] = useState(0);
  const [totalPayable, setTotalPayable] = useState(0);
  const [installment, setInstallment] = useState(0);
  const [maturityDate, setMaturityDate] = useState('');

  useEffect(() => {
    // Calculate maturity date
    const today = new Date();
    if (periodType === 'Months') {
      today.setMonth(today.getMonth() + parseInt(duration || 0));
    } else {
      today.setDate(today.getDate() + parseInt(duration || 0));
    }
    setMaturityDate(today.toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' }));

    // Fee calculation (1% of loan amount)
    const fee = Math.round(amount * 0.01);
    setProcessingFee(fee);

    // Interest & EMI calculation
    const P = parseFloat(amount) || 0;
    const R = parseFloat(interestRate) || 0;
    const T = parseFloat(duration) || 0;

    let interest = 0;
    let pay = 0;
    let inst = 0;

    if (calcMethod === 'Simple') {
      // Simple flat interest
      const timeInYears = periodType === 'Months' ? T / 12 : T / 365;
      interest = Math.round(P * (R / 100) * timeInYears);
      pay = P + interest;
      inst = T > 0 ? Math.round(pay / T) : pay;
    } else {
      // Reducing EMI
      // Monthly interest rate
      const r = (R / 12) / 100;
      const n = periodType === 'Months' ? T : T / 30; // approx
      if (r > 0 && n > 0) {
        inst = Math.round((P * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1));
        pay = Math.round(inst * n);
        interest = pay - P;
      } else {
        interest = 0;
        pay = P;
        inst = P;
      }
    }

    setTotalInterest(interest);
    setTotalPayable(pay);
    setInstallment(inst);

  }, [amount, interestRate, periodType, duration, calcMethod]);

  const interestPercentOfTotal = totalPayable > 0 ? (totalInterest / totalPayable) * 100 : 0;
  const principalPercentOfTotal = 100 - interestPercentOfTotal;

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      <PageHeader
        title="Loan Calculator"
        subtitle="Simulate and calculate gold loan EMI, interest rates, processing fees, and maturity details."
        icon={Calculator}
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Input Form Column */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="p-6">
            <h3 className="text-base font-bold text-gray-900 mb-6 flex items-center gap-2">
              <TrendingUp size={18} className="text-green-600" />
              Configure Loan Parameters
            </h3>

            <form className="space-y-6">
              {/* Loan Amount */}
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <label className="text-[11px] font-bold text-gray-500 uppercase tracking-wider">Loan Amount (₹)</label>
                  <span className="text-sm font-bold text-green-700">₹{amount.toLocaleString('en-IN')}</span>
                </div>
                <Input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(Math.max(0, parseInt(e.target.value) || 0))}
                  placeholder="Enter loan amount"
                  className="font-semibold text-lg"
                />
                <input
                  type="range"
                  min="5000"
                  max="1000000"
                  step="5000"
                  value={amount}
                  onChange={(e) => setAmount(parseInt(e.target.value))}
                  className="w-full h-2 bg-gray-100 rounded-lg appearance-none cursor-pointer accent-green-600"
                />
              </div>

              {/* Interest Rate */}
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <label className="text-[11px] font-bold text-gray-500 uppercase tracking-wider">Interest Rate (% p.a.)</label>
                  <span className="text-sm font-bold text-green-700">{interestRate}%</span>
                </div>
                <Input
                  type="number"
                  value={interestRate}
                  onChange={(e) => setInterestRate(Math.max(0, parseFloat(e.target.value) || 0))}
                  placeholder="Enter interest rate"
                  className="font-semibold text-lg"
                />
                <input
                  type="range"
                  min="1"
                  max="36"
                  step="0.5"
                  value={interestRate}
                  onChange={(e) => setInterestRate(parseFloat(e.target.value))}
                  className="w-full h-2 bg-gray-100 rounded-lg appearance-none cursor-pointer accent-green-600"
                />
              </div>

              {/* Period Configuration */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Select
                  label="Period Type"
                  value={periodType}
                  onChange={(e) => {
                    setPeriodType(e.target.value);
                    setDuration(e.target.value === 'Months' ? 12 : 180);
                  }}
                >
                  <option value="Months">Months</option>
                  <option value="Days">Days</option>
                </Select>

                <Input
                  label={`Duration (${periodType})`}
                  type="number"
                  value={duration}
                  onChange={(e) => setDuration(Math.max(1, parseInt(e.target.value) || 0))}
                />
              </div>

              {/* Calculation Method */}
              <div className="space-y-2">
                <label className="block text-[11px] font-bold text-gray-500 uppercase tracking-wider mb-2">Calculation Method</label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setCalcMethod('Simple')}
                    className={`p-3.5 rounded-xl border text-sm font-bold flex flex-col items-center gap-1.5 transition-all cursor-pointer ${
                      calcMethod === 'Simple'
                        ? 'border-green-600 bg-green-50 text-green-700'
                        : 'border-gray-200 hover:bg-gray-50 text-gray-600'
                    }`}
                  >
                    <span>Simple Interest</span>
                    <span className="text-[10px] opacity-75 font-medium">Flat Rate Scheme</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setCalcMethod('EMI')}
                    className={`p-3.5 rounded-xl border text-sm font-bold flex flex-col items-center gap-1.5 transition-all cursor-pointer ${
                      calcMethod === 'EMI'
                        ? 'border-green-600 bg-green-50 text-green-700'
                        : 'border-gray-200 hover:bg-gray-50 text-gray-600'
                    }`}
                  >
                    <span>EMI Scheme</span>
                    <span className="text-[10px] opacity-75 font-medium">Reducing Balance</span>
                  </button>
                </div>
              </div>
            </form>
          </Card>
        </div>

        {/* Calculation Result Column */}
        <div className="space-y-6">
          <Card className="overflow-hidden border border-gray-200 shadow-md">
            {/* Upper green panel */}
            <div className="bg-gradient-to-br from-green-700 to-green-950 p-6 text-white text-center">
              <p className="text-[11px] font-bold tracking-wider uppercase opacity-80 mb-1">
                {calcMethod === 'EMI' ? 'Estimated EMI' : 'Estimated Payment'}
              </p>
              <h2 className="text-4xl font-extrabold tracking-tight mb-2">
                ₹{installment.toLocaleString('en-IN')}
                <span className="text-sm font-medium opacity-80">
                  /{periodType === 'Months' ? 'mo' : 'day'}
                </span>
              </h2>
              <div className="inline-flex items-center gap-1.5 bg-white/10 px-3 py-1 rounded-full text-xs font-semibold backdrop-blur-sm mt-1">
                <Calendar size={13} />
                Maturity: {maturityDate}
              </div>
            </div>

            {/* Cost Breakdown details */}
            <div className="p-6 space-y-4">
              <div className="flex justify-between items-center text-sm py-1 border-b border-gray-100">
                <span className="text-gray-500 font-medium">Principal Amount</span>
                <span className="font-bold text-gray-800">₹{amount.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between items-center text-sm py-1 border-b border-gray-100">
                <span className="text-gray-500 font-medium">Total Interest Rate</span>
                <span className="font-bold text-gray-800">₹{totalInterest.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between items-center text-sm py-1 border-b border-gray-100">
                <span className="text-gray-500 font-medium">Processing Fee (1%)</span>
                <span className="font-bold text-gray-800">₹{processingFee.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between items-center text-sm pt-2">
                <span className="text-gray-900 font-bold">Total Payable</span>
                <span className="font-extrabold text-green-700 text-lg">₹{totalPayable.toLocaleString('en-IN')}</span>
              </div>

              {/* Graphic Breakdown */}
              <div className="pt-6">
                <p className="text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-3">Cost Breakdown</p>
                <div className="w-full h-3 bg-gray-100 rounded-full overflow-hidden flex">
                  <div style={{ width: `${principalPercentOfTotal}%` }} className="bg-green-600 transition-all duration-300" title={`Principal: ${Math.round(principalPercentOfTotal)}%`} />
                  <div style={{ width: `${interestPercentOfTotal}%` }} className="bg-amber-400 transition-all duration-300" title={`Interest: ${Math.round(interestPercentOfTotal)}%`} />
                </div>
                <div className="flex items-center gap-4 mt-3 text-xs">
                  <div className="flex items-center gap-1.5 font-semibold text-gray-600">
                    <span className="w-2.5 h-2.5 rounded-full bg-green-600" />
                    Principal ({Math.round(principalPercentOfTotal)}%)
                  </div>
                  <div className="flex items-center gap-1.5 font-semibold text-gray-600">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
                    Interest ({Math.round(interestPercentOfTotal)}%)
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </div>

      </div>
    </div>
  );
};

export default LoanCalculator;
