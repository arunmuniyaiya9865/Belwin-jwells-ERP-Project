import { useState, useEffect } from 'react';
import { Plus, Edit3, Trash2, Search, UserCheck, ArrowLeft } from 'lucide-react';
import api from '../../../services/api';
import PageHeader from '../../../components/ui/PageHeader';
import Card from '../../../components/ui/Card';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';
import Badge from '../../../components/ui/Badge';
import DataTable from '../../../components/ui/DataTable';
import ConfirmDialog from '../../../components/ui/ConfirmDialog';
import { TD, TR } from '../../../components/ui/Table';

const STORAGE_KEY = 'bellwin_valuers';

const ValuerMaster = () => {
  const [valuers, setValuers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  
  // Form states
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingValuer, setEditingValuer] = useState(null);
  const [formData, setFormData] = useState({
    valuerName: '',
    employeeId: '',
    mobileNumber: '',
    qualification: '',
    experience: '',
    branch: 'Head Office',
    status: 'Active'
  });

  // Delete dialog state
  const [deleteId, setDeleteId] = useState(null);

  // Fetch valuers
  const fetchValuers = async () => {
    setLoading(true);
    try {
      const res = await api.get('/loan-config/valuer');
      if (res.data && res.data.valuers) {
        setValuers(res.data.valuers);
      } else if (Array.isArray(res.data)) {
        setValuers(res.data);
      } else {
        throw new Error('API response empty');
      }
    } catch (err) {
      console.warn('API valuer not available, falling back to LocalStorage', err);
      const local = localStorage.getItem(STORAGE_KEY);
      if (local) {
        setValuers(JSON.parse(local));
      } else {
        const defaults = [
          {
            _id: '1',
            valuerName: 'A. R. SHANMUGAM',
            employeeId: 'EMP-0052',
            mobileNumber: '9840224466',
            qualification: 'Certified Gold Assayer (DGGA)',
            experience: '8 Years',
            branch: 'Head Office',
            status: 'Active'
          },
          {
            _id: '2',
            valuerName: 'M. BALAKRISHNAN',
            employeeId: 'EMP-0091',
            mobileNumber: '9840113355',
            qualification: 'GIA Graduate Gemologist',
            experience: '5 Years',
            branch: 'Branch 01',
            status: 'Active'
          }
        ];
        localStorage.setItem(STORAGE_KEY, JSON.stringify(defaults));
        setValuers(defaults);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchValuers();
  }, []);

  const handleOpenAdd = () => {
    setEditingValuer(null);
    setFormData({
      valuerName: '',
      employeeId: '',
      mobileNumber: '',
      qualification: '',
      experience: '',
      branch: 'Head Office',
      status: 'Active'
    });
    setIsFormOpen(true);
  };

  const handleOpenEdit = (valuer) => {
    setEditingValuer(valuer);
    setFormData({
      valuerName: valuer.valuerName || '',
      employeeId: valuer.employeeId || '',
      mobileNumber: valuer.mobileNumber || '',
      qualification: valuer.qualification || '',
      experience: valuer.experience || '',
      branch: valuer.branch || 'Head Office',
      status: valuer.status || 'Active'
    });
    setIsFormOpen(true);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    if (!formData.valuerName || !formData.mobileNumber) return alert('Name and Mobile Number are required');
    if (formData.mobileNumber.length !== 10) return alert('Mobile must be 10 digits');

    setLoading(true);
    try {
      if (editingValuer) {
        try {
          await api.put(`/loan-config/valuer/${editingValuer._id}`, formData);
        } catch (apiErr) {
          const updated = valuers.map(v => v._id === editingValuer._id ? { ...v, ...formData } : v);
          localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
        }
      } else {
        try {
          await api.post('/loan-config/valuer', formData);
        } catch (apiErr) {
          const newValuer = {
            _id: Date.now().toString(),
            ...formData
          };
          const updated = [...valuers, newValuer];
          localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
        }
      }
      setIsFormOpen(false);
      await fetchValuers();
    } catch (err) {
      console.error(err);
      alert('Failed to save valuer');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    setLoading(true);
    try {
      try {
        await api.delete(`/loan-config/valuer/${deleteId}`);
      } catch (apiErr) {
        const updated = valuers.filter(v => v._id !== deleteId);
        localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      }
      setDeleteId(null);
      await fetchValuers();
    } catch (err) {
      console.error(err);
      alert('Failed to delete valuer');
    } finally {
      setLoading(false);
    }
  };

  const filteredValuers = valuers.filter(v =>
    v.valuerName?.toLowerCase().includes(search.toLowerCase()) ||
    v.employeeId?.toLowerCase().includes(search.toLowerCase()) ||
    v.qualification?.toLowerCase().includes(search.toLowerCase())
  );

  if (isFormOpen) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-6 animate-fade-in">
        <div className="flex items-center gap-4 mb-6">
          <button 
            onClick={() => setIsFormOpen(false)}
            className="p-2 text-gray-500 hover:text-green-600 hover:bg-green-50 rounded-xl transition-colors"
          >
            <ArrowLeft size={24} />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              {editingValuer ? 'Edit Valuer Details' : 'Add Licensed Valuer'}
            </h1>
            <p className="text-sm text-gray-500 mt-1">
              {editingValuer ? 'Update the details of the licensed gold valuer.' : 'Register a new licensed gold valuer into the system.'}
            </p>
          </div>
        </div>

        <Card className="p-8 shadow-lg border border-gray-100">
          <form onSubmit={handleSave} className="space-y-6">
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Input
                label="Valuer Name"
                required
                value={formData.valuerName}
                onChange={(e) => setFormData({ ...formData, valuerName: e.target.value.toUpperCase() })}
                placeholder="e.g. A. R. SHANMUGAM"
                className="bg-gray-50"
              />
              <Input
                label="Employee ID (Optional)"
                value={formData.employeeId}
                onChange={(e) => setFormData({ ...formData, employeeId: e.target.value.toUpperCase() })}
                placeholder="e.g. EMP-0052"
                className="bg-gray-50"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Input
                label="Mobile Number"
                required
                maxLength={10}
                value={formData.mobileNumber}
                onChange={(e) => {
                  const val = e.target.value;
                  if (val === '' || /^[0-9]+$/.test(val)) {
                    setFormData({ ...formData, mobileNumber: val });
                  }
                }}
                placeholder="e.g. 9840224466"
                className="bg-gray-50"
              />
              <Input
                label="Experience (e.g. 5 Years)"
                value={formData.experience}
                onChange={(e) => setFormData({ ...formData, experience: e.target.value.toUpperCase() })}
                placeholder="e.g. 8 YEARS"
                className="bg-gray-50"
              />
            </div>

            <div className="space-y-1.5">
              <Input
                label="Assaying Qualification"
                value={formData.qualification}
                onChange={(e) => setFormData({ ...formData, qualification: e.target.value.toUpperCase() })}
                placeholder="e.g. CERTIFIED GOLD ASSAYER (DGGA)"
                className="bg-gray-50"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-4">
              <Select
                label="Branch Allocation"
                value={formData.branch}
                onChange={(e) => setFormData({ ...formData, branch: e.target.value })}
                containerClassName="bg-gray-50"
              >
                <option value="Head Office">Head Office</option>
                <option value="Branch 01">Branch 01</option>
                <option value="Branch 02">Branch 02</option>
              </Select>
              
              <Select
                label="Status"
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                containerClassName="bg-gray-50"
              >
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </Select>
            </div>

            <div className="flex items-center justify-end gap-4 pt-6 border-t border-gray-100">
              <Button 
                type="button" 
                onClick={() => setIsFormOpen(false)} 
                variant="secondary"
                className="px-6 py-2.5"
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                variant="primary" 
                loading={loading}
                className="px-8 py-2.5 shadow-md hover:shadow-lg transition-all"
              >
                Save Valuer
              </Button>
            </div>
            
          </form>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 animate-fade-in">
      <PageHeader
        title="Valuer Master"
        subtitle="Manage licensed gold assayers, qualifications, experience, and branch allocations."
        icon={UserCheck}
        actions={
          <Button onClick={handleOpenAdd} icon={Plus} variant="primary">
            Add Valuer
          </Button>
        }
      />

      <Card className="p-4 mb-6 shadow-sm border border-gray-100">
        <div className="relative max-w-md">
          <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
            <Search size={16} />
          </span>
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by valuer name, ID or qualification..."
            className="w-full pl-9 pr-4 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-green-500 focus:ring-1 focus:ring-green-500 bg-gray-50"
          />
        </div>
      </Card>

      <DataTable
        headers={[
          'Employee ID',
          'Valuer Name',
          'Mobile Number',
          'Qualification',
          'Experience',
          'Branch',
          'Status',
          'Actions'
        ]}
        data={filteredValuers}
        loading={loading}
        renderRow={(valuer) => (
          <TR key={valuer._id}>
            <TD className="font-bold text-gray-800">{valuer.employeeId || 'N/A'}</TD>
            <TD className="font-semibold">{valuer.valuerName}</TD>
            <TD>{valuer.mobileNumber}</TD>
            <TD className="text-gray-600 text-xs font-semibold">{valuer.qualification}</TD>
            <TD>{valuer.experience}</TD>
            <TD>{valuer.branch}</TD>
            <TD>
              <Badge variant={valuer.status === 'Active' ? 'success' : 'danger'}>
                {valuer.status}
              </Badge>
            </TD>
            <TD>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleOpenEdit(valuer)}
                  className="p-1.5 text-gray-500 hover:text-green-600 hover:bg-green-50 rounded-lg cursor-pointer transition-colors"
                  title="Edit Valuer"
                >
                  <Edit3 size={15} />
                </button>
                <button
                  onClick={() => setDeleteId(valuer._id)}
                  className="p-1.5 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-lg cursor-pointer transition-colors"
                  title="Delete Valuer"
                >
                  <Trash2 size={15} />
                </button>
              </div>
            </TD>
          </TR>
        )}
      />

      <ConfirmDialog
        isOpen={!!deleteId}
        onClose={() => setDeleteId(null)}
        onConfirm={handleDelete}
        title="Delete Valuer Record"
        description="Are you sure you want to delete this valuer record? This action cannot be undone."
        confirmText="Delete"
        cancelText="Cancel"
        variant="danger"
      />
    </div>
  );
};

export default ValuerMaster;
