import { useState, useEffect } from 'react';
import { Plus, Edit3, Trash2, Search, Car, ArrowLeft } from 'lucide-react';
import api from '../../../services/api';
import PageHeader from '../../../components/ui/PageHeader';
import Card from '../../../components/ui/Card';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';
import Badge from '../../../components/ui/Badge';
import DataTable from '../../../components/ui/DataTable';
import ConfirmDialog from '../../../components/ui/ConfirmDialog';
import { TD, TR } from '../../../components/ui/Table';

const STORAGE_KEY = 'bellwin_vehicles';

const VehicleMaster = () => {
  const [vehicles, setVehicles] = useState([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  
  // Modal states
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingVehicle, setEditingVehicle] = useState(null);
  const [formData, setFormData] = useState({
    vehicleId: '',
    vehicleName: '',
    vehicleType: 'Two-Wheeler',
    registrationNumber: '',
    status: 'Active'
  });

  // Delete dialog state
  const [deleteId, setDeleteId] = useState(null);

  // Fetch vehicles
  const fetchVehicles = async () => {
    setLoading(true);
    try {
      const res = await api.get('/loan-config/vehicle');
      setVehicles(res.data.vehicles || res.data || []);
    } catch (err) {
      console.warn('API vehicle not available, falling back to LocalStorage', err);
      const local = localStorage.getItem(STORAGE_KEY);
      if (local) {
        setVehicles(JSON.parse(local));
      } else {
        const defaults = [
          {
            _id: '1',
            vehicleId: 'VEH-0001',
            vehicleName: 'Honda Activa 6G',
            vehicleType: 'Two-Wheeler',
            registrationNumber: 'TN-01-AB-1234',
            status: 'Active'
          },
          {
            _id: '2',
            vehicleId: 'VEH-0002',
            vehicleName: 'Maruti Suzuki Swift',
            vehicleType: 'Four-Wheeler',
            registrationNumber: 'TN-02-CD-5678',
            status: 'Active'
          }
        ];
        localStorage.setItem(STORAGE_KEY, JSON.stringify(defaults));
        setVehicles(defaults);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchVehicles();
  }, []);

  const handleOpenAdd = () => {
    setEditingVehicle(null);
    setFormData({
      vehicleId: `VEH-${String(vehicles.length + 1).padStart(4, '0')}`,
      vehicleName: '',
      vehicleType: 'Two-Wheeler',
      registrationNumber: '',
      status: 'Active'
    });
    setIsFormOpen(true);
  };

  const handleOpenEdit = (vehicle) => {
    setEditingVehicle(vehicle);
    setFormData({
      vehicleId: vehicle.vehicleId || '',
      vehicleName: vehicle.vehicleName || '',
      vehicleType: vehicle.vehicleType || 'Two-Wheeler',
      registrationNumber: vehicle.registrationNumber || '',
      status: vehicle.status || 'Active'
    });
    setIsFormOpen(true);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    if (!formData.vehicleName || !formData.registrationNumber) return alert('Name and Registration Number are required');

    setLoading(true);
    try {
      if (editingVehicle) {
        try {
          await api.put(`/loan-config/vehicle/${editingVehicle._id}`, formData);
        } catch (apiErr) {
          const updated = vehicles.map(v => v._id === editingVehicle._id ? { ...v, ...formData } : v);
          localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
        }
      } else {
        try {
          await api.post('/loan-config/vehicle', formData);
        } catch (apiErr) {
          const newVehicle = {
            _id: Date.now().toString(),
            ...formData
          };
          const updated = [...vehicles, newVehicle];
          localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
        }
      }
      setIsFormOpen(false);
      fetchVehicles();
    } catch (err) {
      console.error(err);
      alert('Failed to save vehicle');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    setLoading(true);
    try {
      try {
        await api.delete(`/loan-config/vehicle/${deleteId}`);
      } catch (apiErr) {
        const updated = vehicles.filter(v => v._id !== deleteId);
        localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      }
      setDeleteId(null);
      fetchVehicles();
    } catch (err) {
      console.error(err);
      alert('Failed to delete vehicle');
    } finally {
      setLoading(false);
    }
  };

  const filteredVehicles = vehicles.filter(v =>
    v.vehicleName?.toLowerCase().includes(search.toLowerCase()) ||
    v.registrationNumber?.toLowerCase().includes(search.toLowerCase()) ||
    v.vehicleId?.toLowerCase().includes(search.toLowerCase())
  );

  if (isFormOpen) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-6 animate-fade-in">
        <div className="flex items-center gap-4 mb-6">
          <button 
            onClick={() => setIsFormOpen(false)}
            className="p-2 text-gray-500 hover:text-green-600 hover:bg-green-50 rounded-xl transition-colors"
          >
            <ArrowLeft size={24} />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              {editingVehicle ? 'Edit Vehicle Master' : 'Add New Vehicle'}
            </h1>
          </div>
        </div>

        <Card className="p-8 shadow-lg border border-gray-100">
          <form onSubmit={handleSave} className="space-y-4">
          <Input
            label="Vehicle ID"
            required
            disabled
            value={formData.vehicleId}
            onChange={(e) => setFormData({ ...formData, vehicleId: e.target.value.toUpperCase() })}
          />
          <Input
            label="Vehicle Name / Model"
            required
            value={formData.vehicleName}
            onChange={(e) => setFormData({ ...formData, vehicleName: e.target.value.toUpperCase() })}
            placeholder="e.g. HONDA ACTIVA 6G"
          />
          <Select
            label="Vehicle Type"
            value={formData.vehicleType}
            onChange={(e) => setFormData({ ...formData, vehicleType: e.target.value })}
          >
            <option value="Two-Wheeler">Two-Wheeler</option>
            <option value="Four-Wheeler">Four-Wheeler</option>
            <option value="Three-Wheeler">Three-Wheeler</option>
          </Select>
          <Input
            label="Registration Number"
            required
            value={formData.registrationNumber}
            onChange={(e) => setFormData({ ...formData, registrationNumber: e.target.value.toUpperCase() })}
            placeholder="e.g. TN-01-AB-1234"
          />
          <Select
            label="Status"
            value={formData.status}
            onChange={(e) => setFormData({ ...formData, status: e.target.value })}
          >
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
          </Select>
          
            <div className="flex items-center justify-end gap-4 pt-6 border-t border-gray-100 mt-6">
              <Button 
                type="button" 
                onClick={() => setIsFormOpen(false)} 
                variant="secondary"
                className="px-6 py-2.5"
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                variant="primary" 
                loading={loading}
                className="px-8 py-2.5 shadow-md hover:shadow-lg transition-all"
              >
                Save Vehicle
              </Button>
            </div>
        </form>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 animate-fade-in">
      <PageHeader
        title="Vehicle Master"
        subtitle="Manage details of company-owned two-wheelers and four-wheelers used for field operations."
        icon={Car}
        actions={
          <Button onClick={handleOpenAdd} icon={Plus} variant="primary">
            Add Vehicle
          </Button>
        }
      />

      <Card className="p-4 mb-6 shadow-sm border border-gray-100">
        <div className="relative max-w-md">
          <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
            <Search size={16} />
          </span>
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by ID, name or registration..."
            className="w-full pl-9 pr-4 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-green-500 focus:ring-1 focus:ring-green-500 bg-gray-50"
          />
        </div>
      </Card>

      <DataTable
        headers={[
          'Vehicle ID',
          'Vehicle Name',
          'Vehicle Type',
          'Registration Number',
          'Status',
          'Actions'
        ]}
        data={filteredVehicles}
        loading={loading}
        renderRow={(vehicle) => (
          <TR key={vehicle._id}>
            <TD className="font-bold text-gray-800">{vehicle.vehicleId}</TD>
            <TD className="font-semibold">{vehicle.vehicleName}</TD>
            <TD>{vehicle.vehicleType}</TD>
            <TD className="font-semibold text-green-700">{vehicle.registrationNumber}</TD>
            <TD>
              <Badge variant={vehicle.status === 'Active' ? 'success' : 'danger'}>
                {vehicle.status}
              </Badge>
            </TD>
            <TD>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleOpenEdit(vehicle)}
                  className="p-1.5 text-gray-500 hover:text-green-600 hover:bg-green-50 rounded-lg cursor-pointer transition-colors"
                  title="Edit Vehicle"
                >
                  <Edit3 size={15} />
                </button>
                <button
                  onClick={() => setDeleteId(vehicle._id)}
                  className="p-1.5 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-lg cursor-pointer transition-colors"
                  title="Delete Vehicle"
                >
                  <Trash2 size={15} />
                </button>
              </div>
            </TD>
          </TR>
        )}
      />

      

      <ConfirmDialog
        isOpen={!!deleteId}
        onClose={() => setDeleteId(null)}
        onConfirm={handleDelete}
        title="Delete Vehicle"
        description="Are you sure you want to delete this vehicle record? This action cannot be undone."
        confirmText="Delete"
        cancelText="Cancel"
        variant="danger"
      />
    </div>
  );
};

export default VehicleMaster;
