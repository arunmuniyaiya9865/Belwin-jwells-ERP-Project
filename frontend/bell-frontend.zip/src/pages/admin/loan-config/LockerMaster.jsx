import { useState, useEffect } from 'react';
import { Plus, Edit3, Trash2, Search, Key, ArrowLeft } from 'lucide-react';
import api from '../../../services/api';
import PageHeader from '../../../components/ui/PageHeader';
import Card from '../../../components/ui/Card';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';
import Badge from '../../../components/ui/Badge';
import DataTable from '../../../components/ui/DataTable';
import ConfirmDialog from '../../../components/ui/ConfirmDialog';
import { TD, TR } from '../../../components/ui/Table';

const STORAGE_KEY = 'bellwin_lockers';

const LockerMaster = () => {
  const [lockers, setLockers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  
  // Modal states
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingLocker, setEditingLocker] = useState(null);
  const [formData, setFormData] = useState({
    lockerNumber: '',
    lockerType: 'Medium',
    capacity: '',
    branch: 'Head Office',
    availabilityStatus: 'Available'
  });

  // Delete dialog state
  const [deleteId, setDeleteId] = useState(null);

  // Fetch lockers
  const fetchLockers = async () => {
    setLoading(true);
    try {
      const res = await api.get('/loan-config/locker');
      setLockers(res.data.lockers || res.data || []);
    } catch (err) {
      console.warn('API locker not available, falling back to LocalStorage', err);
      const local = localStorage.getItem(STORAGE_KEY);
      if (local) {
        setLockers(JSON.parse(local));
      } else {
        const defaults = [
          {
            _id: '1',
            lockerNumber: 'LK-A01',
            lockerType: 'Small',
            capacity: '5 KG',
            branch: 'Head Office',
            availabilityStatus: 'Available'
          },
          {
            _id: '2',
            lockerNumber: 'LK-B05',
            lockerType: 'Medium',
            capacity: '10 KG',
            branch: 'Branch 01',
            availabilityStatus: 'Occupied'
          },
          {
            _id: '3',
            lockerNumber: 'LK-C10',
            lockerType: 'Large',
            capacity: '25 KG',
            branch: 'Branch 02',
            availabilityStatus: 'Available'
          }
        ];
        localStorage.setItem(STORAGE_KEY, JSON.stringify(defaults));
        setLockers(defaults);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLockers();
  }, []);

  const handleOpenAdd = () => {
    setEditingLocker(null);
    setFormData({
      lockerNumber: '',
      lockerType: 'Medium',
      capacity: '',
      branch: 'Head Office',
      availabilityStatus: 'Available'
    });
    setIsFormOpen(true);
  };

  const handleOpenEdit = (locker) => {
    setEditingLocker(locker);
    setFormData({
      lockerNumber: locker.lockerNumber || '',
      lockerType: locker.lockerType || 'Medium',
      capacity: locker.capacity || '',
      branch: locker.branch || 'Head Office',
      availabilityStatus: locker.availabilityStatus || 'Available'
    });
    setIsFormOpen(true);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    if (!formData.lockerNumber || !formData.capacity) return alert('Number and Capacity are required');

    setLoading(true);
    try {
      if (editingLocker) {
        try {
          await api.put(`/loan-config/locker/${editingLocker._id}`, formData);
        } catch (apiErr) {
          const updated = lockers.map(l => l._id === editingLocker._id ? { ...l, ...formData } : l);
          localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
        }
      } else {
        try {
          await api.post('/loan-config/locker', formData);
        } catch (apiErr) {
          const newLocker = {
            _id: Date.now().toString(),
            ...formData
          };
          const updated = [...lockers, newLocker];
          localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
        }
      }
      setIsFormOpen(false);
      fetchLockers();
    } catch (err) {
      console.error(err);
      alert('Failed to save locker');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    setLoading(true);
    try {
      try {
        await api.delete(`/loan-config/locker/${deleteId}`);
      } catch (apiErr) {
        const updated = lockers.filter(l => l._id !== deleteId);
        localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      }
      setDeleteId(null);
      fetchLockers();
    } catch (err) {
      console.error(err);
      alert('Failed to delete locker');
    } finally {
      setLoading(false);
    }
  };

  const filteredLockers = lockers.filter(l =>
    l.lockerNumber?.toLowerCase().includes(search.toLowerCase()) ||
    l.lockerType?.toLowerCase().includes(search.toLowerCase()) ||
    l.branch?.toLowerCase().includes(search.toLowerCase())
  );

  const getStatusBadgeVariant = (status) => {
    if (status === 'Available') return 'success';
    if (status === 'Occupied') return 'warning';
    return 'danger';
  };

  if (isFormOpen) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-6 animate-fade-in">
        <div className="flex items-center gap-4 mb-6">
          <button 
            onClick={() => setIsFormOpen(false)}
            className="p-2 text-gray-500 hover:text-green-600 hover:bg-green-50 rounded-xl transition-colors"
          >
            <ArrowLeft size={24} />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              {editingLocker ? 'Edit Locker Details' : 'Add New Safe Locker'}
            </h1>
          </div>
        </div>

        <Card className="p-8 shadow-lg border border-gray-100">
          <form onSubmit={handleSave} className="space-y-4">
          <Input
            label="Locker Number / ID"
            required
            value={formData.lockerNumber}
            onChange={(e) => setFormData({ ...formData, lockerNumber: e.target.value.toUpperCase() })}
            placeholder="e.g. LK-A01"
          />
          <Select
            label="Locker Type"
            value={formData.lockerType}
            onChange={(e) => setFormData({ ...formData, lockerType: e.target.value })}
          >
            <option value="Small">Small Size</option>
            <option value="Medium">Medium Size</option>
            <option value="Large">Large Size</option>
            <option value="Extra Large">Extra Large Heavy Safe</option>
          </Select>
          <Input
            label="Weight Capacity Limit"
            required
            value={formData.capacity}
            onChange={(e) => setFormData({ ...formData, capacity: e.target.value.toUpperCase() })}
            placeholder="e.g. 10 KG"
          />
          <Select
            label="Branch"
            value={formData.branch}
            onChange={(e) => setFormData({ ...formData, branch: e.target.value })}
          >
            <option value="Head Office">Head Office</option>
            <option value="Branch 01">Branch 01</option>
            <option value="Branch 02">Branch 02</option>
          </Select>
          <Select
            label="Availability Status"
            value={formData.availabilityStatus}
            onChange={(e) => setFormData({ ...formData, availabilityStatus: e.target.value })}
          >
            <option value="Available">Available</option>
            <option value="Occupied">Occupied</option>
            <option value="Maintenance">Under Maintenance</option>
          </Select>
          
            <div className="flex items-center justify-end gap-4 pt-6 border-t border-gray-100 mt-6">
              <Button 
                type="button" 
                onClick={() => setIsFormOpen(false)} 
                variant="secondary"
                className="px-6 py-2.5"
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                variant="primary" 
                loading={loading}
                className="px-8 py-2.5 shadow-md hover:shadow-lg transition-all"
              >
                Save Locker
              </Button>
            </div>
        </form>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 animate-fade-in">
      <PageHeader
        title="Locker Master"
        subtitle="Manage secure physical safe lockers, branch allocations, weight capacity limits, and availability."
        icon={Key}
        actions={
          <Button onClick={handleOpenAdd} icon={Plus} variant="primary">
            Add Locker
          </Button>
        }
      />

      <Card className="p-4 mb-6 shadow-sm border border-gray-100">
        <div className="relative max-w-md">
          <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-gray-400">
            <Search size={16} />
          </span>
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by locker number, type or branch..."
            className="w-full pl-9 pr-4 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-green-500 focus:ring-1 focus:ring-green-500 bg-gray-50"
          />
        </div>
      </Card>

      <DataTable
        headers={[
          'Locker Number',
          'Locker Type',
          'Weight Capacity',
          'Branch',
          'Availability Status',
          'Actions'
        ]}
        data={filteredLockers}
        loading={loading}
        renderRow={(locker) => (
          <TR key={locker._id}>
            <TD className="font-bold text-gray-800">{locker.lockerNumber}</TD>
            <TD className="font-semibold text-green-700">{locker.lockerType}</TD>
            <TD>{locker.capacity}</TD>
            <TD>{locker.branch}</TD>
            <TD>
              <Badge variant={getStatusBadgeVariant(locker.availabilityStatus)}>
                {locker.availabilityStatus}
              </Badge>
            </TD>
            <TD>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleOpenEdit(locker)}
                  className="p-1.5 text-gray-500 hover:text-green-600 hover:bg-green-50 rounded-lg cursor-pointer transition-colors"
                  title="Edit Locker"
                >
                  <Edit3 size={15} />
                </button>
                <button
                  onClick={() => setDeleteId(locker._id)}
                  className="p-1.5 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-lg cursor-pointer transition-colors"
                  title="Delete Locker"
                >
                  <Trash2 size={15} />
                </button>
              </div>
            </TD>
          </TR>
        )}
      />

      

      <ConfirmDialog
        isOpen={!!deleteId}
        onClose={() => setDeleteId(null)}
        onConfirm={handleDelete}
        title="Delete Locker Record"
        description="Are you sure you want to delete this locker record? This action cannot be undone."
        confirmText="Delete"
        cancelText="Cancel"
        variant="danger"
      />
    </div>
  );
};

export default LockerMaster;
