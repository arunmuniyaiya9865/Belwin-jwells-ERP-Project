import { useState, useEffect } from 'react';
import api from '../../services/api';
import {
  ShieldCheck, Search, Save, Check, X, UserCog, Mail, Phone, BadgeInfo
} from 'lucide-react';

const API = '';
const getToken = () => localStorage.getItem('token');

// Simplified modules for Yes/No toggling based on user request
const PERMISSION_MODULES = [
  { key: 'master', label: 'Master Config & Settings' },
  { key: 'hr', label: 'HR / Workforce Management' },
  { key: 'kyc', label: 'KYC & Borrower Management' },
  { key: 'finance', label: 'Finance & Accounts' },
  { key: 'loan_config', label: 'Loan Configuration' },
  { key: 'reports', label: 'Reports & Analytics' },
  { key: 'approval', label: 'Approval Management' },
  { key: 'repledge', label: 'Repledge Section' },
  { key: 'access_control', label: 'Access and Control' }
];

export default function RolesPermissions() {
  const [employees, setEmployees] = useState([]);
  const [search, setSearch] = useState('');
  const [selectedEmp, setSelectedEmp] = useState({
    employeeName: 'Test Employee',
    employeeId: 'EMP001',
    designation: 'Manager',
    email: 'test@example.com',
    mobileNumber: '1234567890'
  });
  const [permissions, setPermissions] = useState([]);
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState(null);

  const headers = { 'x-auth-token': getToken() };

  const showToast = (msg, type = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  };

  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        const res = await api.get(`${API}/master/employee`, { headers });
        let apiData = res.data.employees || res.data || [];
        if (!Array.isArray(apiData)) apiData = [];
        
        const local = localStorage.getItem('bellwin_employee_master');
        const localData = local ? JSON.parse(local) : [];
        
        // If API is empty but local has data, use local data.
        const finalData = apiData.length > 0 ? apiData : localData;
        setEmployees(finalData);
      } catch (e) {
        console.error('API fetch failed, trying local storage', e);
        const local = localStorage.getItem('bellwin_employee_master');
        setEmployees(local ? JSON.parse(local) : []);
      }
    };
    fetchEmployees();
  }, []);

  // Handle Search and Selection
  useEffect(() => {
    const dummyEmp = {
      employeeName: 'Test Employee',
      employeeId: 'EMP001',
      designation: 'Manager',
      email: 'test@example.com',
      mobileNumber: '1234567890'
    };

    if (!search.trim()) {
      setSelectedEmp(dummyEmp);
      return;
    }
    
    // Find partial match based on employeeId, employeeCode or Name
    const term = search.toLowerCase();
    const match = employees.find(e => 
      e.employeeId?.toLowerCase().includes(term) ||
      e.employeeCode?.toLowerCase().includes(term) ||
      e.employeeName?.toLowerCase().includes(term)
    );

    if (match) {
      setSelectedEmp(match);
      setPermissions(match.permissions || []);
    } else {
      setSelectedEmp(dummyEmp);
      setPermissions([]);
    }
  }, [search, employees]);

  const togglePermission = (key) => {
    setPermissions(prev => 
      prev.includes(key) ? prev.filter(p => p !== key) : [...prev, key]
    );
  };

  const handleSave = async () => {
    if (!selectedEmp) return;
    setSaving(true);
    try {
      // Try API first
      if (selectedEmp._id) {
        await api.put(`${API}/roles/assign/${selectedEmp._id}`, 
          { role: 'Custom', permissions }, 
          { headers }
        ).catch(err => console.warn('API save failed, relying on local storage', err));
      }
      
      // Always update local state & local storage to ensure UI works even without backend
      const updatedEmployees = employees.map(e => 
        (e._id === selectedEmp._id || e.employeeId === selectedEmp.employeeId) 
          ? { ...e, permissions } : e
      );
      setEmployees(updatedEmployees);
      localStorage.setItem('bellwin_employee_master', JSON.stringify(updatedEmployees));
      
      showToast('Permissions updated successfully!');
    } catch (e) {
      showToast('Failed to assign permissions', 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 max-w-[1440px] mx-auto pb-8">
      {/* Toast */}
      {toast && (
        <div className={`fixed top-5 right-6 z-50 px-4 py-3 rounded-xl shadow-lg flex items-center gap-2 text-white text-sm font-bold animate-[slideUp_0.2s_ease] ${
          toast.type === 'success' ? 'bg-emerald-500' : 'bg-red-500'
        }`}>
          <style>{`@keyframes slideUp { from { transform: translateY(20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }`}</style>
          {toast.type === 'success' ? <Check size={16} /> : <X size={16} />}
          {toast.msg}
        </div>
      )}

      {/* Header */}
      <div className="px-6 pt-6 mb-6">
        <div className="flex items-center gap-2.5 mb-1">
          <h1 className="text-xl md:text-2xl font-bold text-gray-900 m-0">Employee Permissions</h1>
        </div>
        <p className="text-xs text-gray-500 m-0">Manage module access for employees</p>
      </div>

      {/* Search Bar */}
      <div className="px-6 mb-8">
        <div className="max-w-2xl bg-white p-2 rounded-2xl shadow-sm border border-gray-200 flex items-center gap-3 focus-within:border-indigo-500 focus-within:ring-2 focus-within:ring-indigo-500/20 transition-all">
          <div className="w-10 h-10 rounded-xl bg-indigo-50 flex items-center justify-center shrink-0">
            <Search size={18} className="text-indigo-600" />
          </div>
          <input 
            type="text" 
            placeholder="Search by Employee ID or Name" 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="flex-1 bg-transparent border-none outline-none text-gray-900 font-medium placeholder:text-gray-400 placeholder:font-normal"
          />
          {search && (
            <button onClick={() => setSearch('')} className="p-2 text-gray-400 hover:text-gray-600 cursor-pointer mr-1">
              <X size={18} />
            </button>
          )}
        </div>
        {!selectedEmp && search.trim().length > 0 && (
          <div className="mt-3 ml-2 text-sm text-red-500 font-medium flex items-center gap-1.5">
            <BadgeInfo size={16} /> No employee found with this ID or Name.
          </div>
        )}
      </div>

      {/* Content Area */}
      {selectedEmp && (
        <div className="px-6 grid grid-cols-1 lg:grid-cols-[350px_1fr] gap-6 animate-[slideUp_0.3s_ease]">
          
          {/* Left Card: Employee Details */}
          <div className="bg-white rounded-3xl border border-gray-200 shadow-sm p-6 h-fit sticky top-6">
            <div className="flex flex-col items-center text-center mb-6">
              <div className="w-24 h-24 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center mb-4 overflow-hidden border-4 border-indigo-50 shadow-md">
                {selectedEmp.photo ? (
                  <img src={selectedEmp.photo} alt="" className="w-full h-full object-cover" />
                ) : (
                  <span className="text-white text-3xl font-bold">
                    {selectedEmp.employeeName ? selectedEmp.employeeName.charAt(0).toUpperCase() : '?'}
                  </span>
                )}
              </div>
              <h2 className="text-xl font-bold text-gray-900 m-0">{selectedEmp.employeeName}</h2>
              <p className="text-indigo-600 font-bold text-sm m-0 mt-1">{selectedEmp.employeeId || selectedEmp.employeeCode}</p>
              <div className="px-3 py-1 rounded-full bg-gray-100 text-gray-600 text-xs font-bold mt-3">
                {selectedEmp.designation || 'Employee'}
              </div>
            </div>

            <div className="space-y-4 pt-4 border-t border-gray-100">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-gray-50 flex items-center justify-center shrink-0">
                  <Mail size={14} className="text-gray-500" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-[10px] font-bold text-gray-500 uppercase">Email Address</div>
                  <div className="text-sm font-medium text-gray-900 truncate">{selectedEmp.email || 'N/A'}</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-gray-50 flex items-center justify-center shrink-0">
                  <Phone size={14} className="text-gray-500" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-[10px] font-bold text-gray-500 uppercase">Phone Number</div>
                  <div className="text-sm font-medium text-gray-900 truncate">{selectedEmp.mobileNumber || selectedEmp.mobile || selectedEmp.phone || 'N/A'}</div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Card: Permissions Toggles */}
          <div className="bg-white rounded-3xl border border-gray-200 shadow-sm flex flex-col h-fit">
            <div className="px-6 py-5 border-b border-gray-100 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <ShieldCheck size={20} className="text-green-600" />
                <h3 className="text-lg font-bold text-gray-900 m-0">Module Permissions</h3>
              </div>
              <div className="px-3 py-1 bg-green-50 text-green-700 text-xs font-bold rounded-full">
                {permissions.length} modules granted
              </div>
            </div>

            <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
              {PERMISSION_MODULES.map((mod) => {
                const isGranted = permissions.includes(mod.key);
                return (
                  <div 
                    key={mod.key}
                    onClick={() => togglePermission(mod.key)}
                    className={`flex items-center justify-between p-4 rounded-2xl border-2 transition-all cursor-pointer ${
                      isGranted ? 'border-green-500 bg-green-50/50' : 'border-gray-100 bg-white hover:border-gray-200'
                    }`}
                  >
                    <div className="font-bold text-gray-800 text-sm">{mod.label}</div>
                    
                    {/* Yes/No Toggle */}
                    <div className="flex items-center bg-gray-100 rounded-full p-1 w-24 relative shadow-inner">
                      <div className={`absolute top-1 bottom-1 w-[44px] rounded-full transition-all duration-300 shadow-sm ${
                        isGranted ? 'bg-green-500 left-[48px]' : 'bg-white left-1'
                      }`} />
                      <div className={`flex-1 text-center text-xs font-bold z-10 transition-colors ${!isGranted ? 'text-gray-800' : 'text-gray-400'}`}>
                        No
                      </div>
                      <div className={`flex-1 text-center text-xs font-bold z-10 transition-colors ${isGranted ? 'text-white' : 'text-gray-400'}`}>
                        Yes
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="p-6 bg-gray-50 border-t border-gray-100 rounded-b-3xl flex justify-end">
              <button 
                onClick={handleSave} 
                disabled={saving}
                className="flex items-center gap-2 px-8 py-3 rounded-xl border-none bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-bold transition-all shadow-md hover:shadow-lg cursor-pointer disabled:opacity-70 disabled:cursor-not-allowed"
              >
                <Save size={18} /> {saving ? 'Saving...' : 'Save Permissions'}
              </button>
            </div>
          </div>
          
        </div>
      )}
    </div>
  );
}
