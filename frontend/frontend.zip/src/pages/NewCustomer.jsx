import React, { useState, useRef, useEffect } from 'react';
import toast from 'react-hot-toast';
import { Upload, Save, RefreshCcw, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';
import { createCustomer, uploadCustomerFile, getNextCustomerId } from '../services/customerService';

// ── Field-name map: frontend form ↔ backend API ───────────────────────────────
const emptyForm = {
    customerName:     '',
    guardianName:     '',
    dateOfBirth:      '',
    age:              '',
    gender:           'Male',
    mobileNumber:     '',
    alternateNumber:  '',
    aadhaarNumber:    '',
    panNumber:        '',
    doorStreet:       '',
    area:             '',
    city:             '',
    postalCode:       '',
    permanentAddress: '',
    temporaryAddress: '',
    voterId:          '',
    occupation:       '',
    proof2Name:       '',
    remarks:          '',
};

const emptyFiles = { photo: null, aadhaarDoc: null, proof2Doc: null };

const NewCustomer = () => {
    const [formData, setFormData]       = useState({ ...emptyForm });
    const [files, setFiles]             = useState({ ...emptyFiles });
    const [previews, setPreviews]       = useState({ photo: null, aadhaarDoc: null, proof2Doc: null });
    const [uploadedFiles, setUploadedFiles] = useState({ photo: null, aadhaarDoc: null, proof2Doc: null });
    
    const [customerId, setCustomerId]   = useState('');
    const [loading, setLoading]         = useState(false);
    const [uploadProgress, setProgress] = useState(0);
    const [fieldErrors, setFieldErrors] = useState({});

    const photoInputRef    = useRef(null);
    const aadhaarInputRef  = useRef(null);
    const proof2InputRef   = useRef(null);

    useEffect(() => {
        fetchNextId();
    }, []);

    const fetchNextId = async () => {
        try {
            const res = await getNextCustomerId();
            if (res.success) setCustomerId(res.customerId);
        } catch (err) {
            console.error('Failed to fetch next customer ID');
        }
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
        setFieldErrors(prev => ({ ...prev, [name]: '' }));
    };

    const handleFileChange = (e, fileKey) => {
        const file = e.target.files?.[0];
        if (!file) return;

        const maxMB = fileKey === 'photo' ? 5 : 10;
        if (file.size > maxMB * 1024 * 1024) {
            toast.error(`File too large. Max ${maxMB}MB allowed.`);
            return;
        }

        setFiles(prev => ({ ...prev, [fileKey]: file }));
        setUploadedFiles(prev => ({ ...prev, [fileKey]: null }));

        if (file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onloadend = () => setPreviews(prev => ({ ...prev, [fileKey]: reader.result }));
            reader.readAsDataURL(file);
        } else {
            setPreviews(prev => ({ ...prev, [fileKey]: 'pdf' }));
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        const required = { customerName: 'Customer Name', guardianName: 'Guardian Name', age: 'Age', mobileNumber: 'Mobile Number', doorStreet: 'Door No/Street', area: 'Area' };
        const newErrors = {};
        Object.entries(required).forEach(([field, label]) => {
            if (!formData[field]) newErrors[field] = `${label} is required`;
        });
        if (Object.keys(newErrors).length) {
            setFieldErrors(newErrors);
            toast.error('Please fill in all required fields');
            return;
        }

        setLoading(true);
        setProgress(0);

        try {
            const updatedMeta = { ...uploadedFiles };
            const uploadTasks = Object.entries(files).filter(([key, file]) => file && !updatedMeta[key]);
            
            if (uploadTasks.length > 0) {
                for (let i = 0; i < uploadTasks.length; i++) {
                    const [key, file] = uploadTasks[i];
                    const baseProgress = (i / uploadTasks.length) * 80;
                    
                    const res = await uploadCustomerFile(key, file, (p) => {
                        setProgress(Math.round(baseProgress + (p * 0.8 / uploadTasks.length)));
                    }, customerId);
                    
                    if (res.success && res.data[key]) {
                        updatedMeta[key] = res.data[key];
                        setUploadedFiles(prev => ({ ...prev, [key]: res.data[key] }));
                    }
                }
            }
            setProgress(90);

            const finalFormData = {
                ...formData,
                customerId,
                customerPhotoUrl:          updatedMeta.photo?.url,
                customerPhotoPublicId:     updatedMeta.photo?.publicId,
                aadhaarDocumentUrl:        updatedMeta.aadhaarDoc?.url,
                aadhaarDocumentPublicId:   updatedMeta.aadhaarDoc?.publicId,
                proof2DocumentUrl:         updatedMeta.proof2Doc?.url,
                proof2DocumentPublicId:    updatedMeta.proof2Doc?.publicId,
            };

            const result = await createCustomer(finalFormData);
            setProgress(100);
            
            toast.success(`Customer ${result.data.customerId} saved successfully!`);
            handleClear();
        } catch (err) {
            console.error('Submission error:', err);
            const apiErrors = err?.response?.data?.errors;
            if (apiErrors?.length) {
                const mapped = {};
                apiErrors.forEach(e => { mapped[e.field] = e.message; });
                setFieldErrors(mapped);
                toast.error('Please fix highlighted fields');
            } else {
                toast.error(err?.response?.data?.message || 'Failed to save customer');
            }
        } finally {
            setLoading(false);
            setProgress(0);
        }
    };

    const handleClear = () => {
        setFormData({ ...emptyForm });
        setFiles({ ...emptyFiles });
        setPreviews({ photo: null, aadhaarDoc: null, proof2Doc: null });
        setUploadedFiles({ photo: null, aadhaarDoc: null, proof2Doc: null });
        setFieldErrors({});
        fetchNextId();
        [photoInputRef, aadhaarInputRef, proof2InputRef].forEach(r => r.current && (r.current.value = ''));
    };

    // ── Style helpers ─────────────────────────────────────────────────────────
    const inp = (field) =>
        `w-full px-3 py-1.5 text-base bg-white border shadow-sm rounded-md transition-colors focus:outline-none focus:ring-1 ` +
        (fieldErrors[field]
            ? 'border-red-400 focus:ring-red-400 focus:border-red-400'
            : 'border-gray-300 focus:ring-green-500 focus:border-green-500');

    const lbl = "block text-sm font-semibold text-gray-700 mb-0.5";
    const errMsg = (field) => fieldErrors[field]
        ? <p className="text-xs text-red-500 mt-0.5">{fieldErrors[field]}</p>
        : null;

    // ── File slot renderer ────────────────────────────────────────────────────
    const FileSlot = ({ label, fileKey, inputRef, accept }) => (
        <div>
            <label className={lbl}>{label}</label>
            <div className="flex items-start gap-2">
                {fileKey === 'proof2Doc' && (
                    <input
                        type="text"
                        name="proof2Name"
                        value={formData.proof2Name}
                        onChange={handleInputChange}
                        placeholder="Proof name…"
                        className="w-28 px-2 py-1.5 text-xs bg-white border border-gray-300 shadow-sm rounded-md focus:ring-1 focus:ring-green-500 focus:border-green-500 outline-none shrink-0"
                    />
                )}
                <div className="flex flex-col gap-1 flex-1">
                    <button
                        type="button"
                        onClick={() => inputRef.current.click()}
                        disabled={loading}
                        className="flex items-center px-3 py-1.5 bg-white border border-gray-300 shadow-sm rounded-md text-xs font-medium text-gray-700 hover:bg-gray-50 shrink-0 transition-colors disabled:opacity-50"
                    >
                        <Upload className="w-3 h-3 mr-1" />
                        {files[fileKey] ? 'Change' : 'Browse'}
                    </button>
                    <span className="text-xs text-gray-500 truncate">
                        {files[fileKey] ? files[fileKey].name : 'No file chosen'}
                    </span>
                    {/* Preview */}
                    {previews[fileKey] && previews[fileKey] !== 'pdf' && (
                        <img src={previews[fileKey]} alt="preview"
                            className="mt-1 h-16 w-24 object-cover rounded border border-gray-200" />
                    )}
                    {previews[fileKey] === 'pdf' && (
                        <div className="mt-1 flex items-center gap-1 text-xs text-red-600 font-medium">
                            <CheckCircle className="w-3 h-3" /> PDF ready
                        </div>
                    )}
                </div>
            </div>
            <input type="file" ref={inputRef} onChange={e => handleFileChange(e, fileKey)}
                className="hidden" accept={accept} />
        </div>
    );

    return (
        <div className="flex flex-col" style={{ height: 'calc(100vh - 100px)' }}>
            {/* Title */}
            <div className="mb-3 shrink-0 flex items-start justify-between">
                <div>
                    <h2 className="text-2xl font-bold text-text-primary">Add New Customer</h2>
                    <p className="text-xs text-text-secondary mt-0.5">
                        Fields marked with <span className="text-red-500">*</span> are required.
                        Customer will be set to <span className="font-semibold text-amber-600">Approval Pending</span> on save.
                    </p>
                </div>
                {/* Upload progress */}
                {loading && uploadProgress > 0 && (
                    <div className="flex items-center gap-2 text-sm text-green-700 font-medium">
                        <Loader2 className="w-4 h-4 animate-spin" />
                        Uploading… {uploadProgress}%
                    </div>
                )}
            </div>

            {/* Progress bar */}
            {loading && (
                <div className="w-full h-1 bg-gray-200 rounded-full mb-2 shrink-0 overflow-hidden">
                    <div
                        className="h-full bg-green-500 rounded-full transition-all duration-300"
                        style={{ width: `${uploadProgress || 10}%` }}
                    />
                </div>
            )}

            {/* Form card */}
            <div className="bg-white border border-gray-100 rounded-lg shadow-sm flex-1 flex flex-col overflow-hidden">
                <div className="p-4 flex-1 overflow-auto">
                    <form id="new-customer-form" onSubmit={handleSubmit} className="grid grid-cols-4 gap-x-5 gap-y-3">

                        {/* ── Row 1: Personal ── */}
                        <div>
                            <label className={lbl}>Customer Name <span className="text-red-500">*</span></label>
                            <input type="text" name="customerName" value={formData.customerName}
                                onChange={handleInputChange} className={inp('customerName')} />
                            {errMsg('customerName')}
                        </div>
                        <div>
                            <label className={lbl}>Guardian Name <span className="text-red-500">*</span></label>
                            <input type="text" name="guardianName" value={formData.guardianName}
                                onChange={handleInputChange} className={inp('guardianName')} />
                            {errMsg('guardianName')}
                        </div>
                        <div>
                            <label className={lbl}>Date of Birth</label>
                            <input type="date" name="dateOfBirth" value={formData.dateOfBirth}
                                onChange={handleInputChange} className={inp('dateOfBirth')} />
                        </div>
                        <div className="flex gap-3">
                            <div className="flex-1">
                                <label className={lbl}>Age <span className="text-red-500">*</span></label>
                                <input type="number" name="age" value={formData.age} min="1" max="120"
                                    onChange={handleInputChange} className={inp('age')} />
                                {errMsg('age')}
                            </div>
                            <div className="flex-1">
                                <label className={lbl}>Gender</label>
                                <div className="flex items-center gap-3 mt-1.5">
                                    {['Male','Female','Other'].map(g => (
                                        <label key={g} className="flex items-center text-xs cursor-pointer">
                                            <input type="radio" name="gender" value={g}
                                                checked={formData.gender === g}
                                                onChange={handleInputChange}
                                                className="w-3.5 h-3.5 text-green-600 focus:ring-green-500" />
                                            <span className="ml-1 text-gray-700">{g}</span>
                                        </label>
                                    ))}
                                </div>
                            </div>
                        </div>

                        {/* ── Row 2: Contact ── */}
                        <div>
                            <label className={lbl}>Mobile Number <span className="text-red-500">*</span></label>
                            <input type="tel" name="mobileNumber" value={formData.mobileNumber}
                                onChange={handleInputChange} className={inp('mobileNumber')} maxLength={10} />
                            {errMsg('mobileNumber')}
                        </div>
                        <div>
                            <label className={lbl}>Alternate Number</label>
                            <input type="tel" name="alternateNumber" value={formData.alternateNumber}
                                onChange={handleInputChange} className={inp('alternateNumber')} maxLength={10} />
                            {errMsg('alternateNumber')}
                        </div>
                        <div>
                            <label className={lbl}>Aadhaar Number</label>
                            <input type="text" name="aadhaarNumber" value={formData.aadhaarNumber}
                                onChange={handleInputChange} className={inp('aadhaarNumber')} maxLength={14} placeholder="1234 5678 9012" />
                            {errMsg('aadhaarNumber')}
                        </div>
                        <div>
                            <label className={lbl}>PAN Number</label>
                            <input type="text" name="panNumber" value={formData.panNumber}
                                onChange={handleInputChange} className={inp('panNumber')} maxLength={10}
                                placeholder="ABCDE1234F" style={{ textTransform: 'uppercase' }} />
                            {errMsg('panNumber')}
                        </div>

                        {/* ── Row 3: Address ── */}
                        <div>
                            <label className={lbl}>Door No / Street <span className="text-red-500">*</span></label>
                            <input type="text" name="doorStreet" value={formData.doorStreet}
                                onChange={handleInputChange} className={inp('doorStreet')} />
                            {errMsg('doorStreet')}
                        </div>
                        <div>
                            <label className={lbl}>Area <span className="text-red-500">*</span></label>
                            <input type="text" name="area" value={formData.area}
                                onChange={handleInputChange} className={inp('area')} />
                            {errMsg('area')}
                        </div>
                        <div>
                            <label className={lbl}>City</label>
                            <input type="text" name="city" value={formData.city}
                                onChange={handleInputChange} className={inp('city')} />
                        </div>
                        <div>
                            <label className={lbl}>Postal Code</label>
                            <input type="text" name="postalCode" value={formData.postalCode}
                                onChange={handleInputChange} className={inp('postalCode')} maxLength={6} />
                            {errMsg('postalCode')}
                        </div>

                        {/* ── Row 4: Address textareas ── */}
                        <div className="col-span-2">
                            <label className={lbl}>Permanent Address</label>
                            <textarea name="permanentAddress" value={formData.permanentAddress}
                                onChange={handleInputChange} rows="2"
                                className={`${inp('permanentAddress')} resize-none`} />
                        </div>
                        <div className="col-span-2">
                            <label className={lbl}>Temporary Address</label>
                            <textarea name="temporaryAddress" value={formData.temporaryAddress}
                                onChange={handleInputChange} rows="2"
                                className={`${inp('temporaryAddress')} resize-none`} />
                        </div>

                        {/* ── Row 5: IDs + misc ── */}
                        <div>
                            <label className={lbl}>Voter ID</label>
                            <input type="text" name="voterId" value={formData.voterId}
                                onChange={handleInputChange} className={inp('voterId')} />
                        </div>
                        <div>
                            <label className={lbl}>Occupation</label>
                            <input type="text" name="occupation" value={formData.occupation}
                                onChange={handleInputChange} className={inp('occupation')} />
                        </div>
                        <div className="col-span-2">
                            <label className={lbl}>Remarks</label>
                            <input type="text" name="remarks" value={formData.remarks}
                                onChange={handleInputChange} className={inp('remarks')} />
                        </div>

                        {/* ── File Uploads ── */}
                        <div className="col-span-4 grid grid-cols-3 gap-5 pt-2 border-t border-gray-100">
                            <FileSlot label="Customer Photo" fileKey="photo"       inputRef={photoInputRef}   accept="image/*" />
                            <FileSlot label="Aadhaar Document" fileKey="aadhaarDoc" inputRef={aadhaarInputRef} accept="image/*,application/pdf" />
                            <FileSlot label="Proof 2 Document" fileKey="proof2Doc"  inputRef={proof2InputRef}  accept="image/*,application/pdf" />
                        </div>

                    </form>
                </div>

                {/* ── Bottom Action Bar ── */}
                <div className="shrink-0 px-4 py-3 border-t border-gray-100 bg-gray-50 rounded-b-lg flex items-center gap-3">
                    <button
                        form="new-customer-form"
                        type="submit"
                        disabled={loading}
                        className="flex items-center gap-2 px-6 py-2 bg-gradient-to-r from-green-600 to-green-700 text-white text-sm font-semibold rounded-lg hover:from-green-700 hover:to-green-800 focus:ring-2 focus:ring-green-500/30 transition-all shadow-sm disabled:opacity-60 disabled:cursor-not-allowed"
                    >
                        {loading
                            ? <><Loader2 className="w-4 h-4 animate-spin" /> Saving…</>
                            : <><Save className="w-4 h-4" /> Save Customer</>
                        }
                    </button>
                    <button
                        type="button"
                        onClick={handleClear}
                        disabled={loading}
                        className="flex items-center gap-2 px-5 py-2 bg-white border border-gray-200 text-gray-700 text-sm font-medium rounded-lg hover:bg-gray-100 transition-all disabled:opacity-50"
                    >
                        <RefreshCcw className="w-4 h-4" /> Clear
                    </button>
                    {Object.keys(fieldErrors).length > 0 && (
                        <span className="flex items-center gap-1 text-xs text-red-500">
                            <AlertCircle className="w-3.5 h-3.5" /> Fix errors above
                        </span>
                    )}
                </div>
            </div>
        </div>
    );
};

export default NewCustomer;
